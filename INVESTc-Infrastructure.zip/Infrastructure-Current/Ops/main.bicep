targetScope = 'subscription'

param env string
param region string

var resourceSuffix = 'investc-${env}'
var rgName = '${resourceSuffix}-ops-rg'

module rg '../../IaC/Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgdeploy'
  params: {
    application: 'investc'
    region: region
    name: rgName
  }
}

module logAnalytics '../../IaC/Modules/Insights/workspace.bicep' = {
  name: '${deployment().name}-omsdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-laws'
  }
  dependsOn: [ rg ]
}

module automationAccount '../../IaC/Modules/Automation/account.bicep' = {
  name: '${deployment().name}-automationdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-aa'
  }
  dependsOn: [ rg ]
}


