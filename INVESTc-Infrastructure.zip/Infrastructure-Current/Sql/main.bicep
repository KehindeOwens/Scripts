targetScope = 'subscription'

param env string
param region string

var resourceSuffix = 'investc-${env}'
var rgName = '${resourceSuffix}-sql-rg'
var keyVaultRgName = '${resourceSuffix}-rg'
var adminGroupOIDs = {
  dev: '02ca92a7-3596-48ac-8649-9a8d7be38bd6'
  stg: '7356a188-9a1b-456c-a2fd-70f2cd404ab0'
  tst: 'b925c86f-708b-40d2-b9b9-459b7b2bd06f'
  prd: '86cdf76f-91bf-482f-8e80-516b6abf3cf4'
  dsr: '814f86a2-fcfc-4996-94f4-e896b1b36504'
}

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: '${resourceSuffix}-kv'
  scope: resourceGroup(keyVaultRgName)
}

module rg '../../IaC/Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgdeploy'
  params: {
    application: 'investc'
    region: region
    name: rgName
  }
}

module sqlServer '../../IaC/Modules/Database/SQL/server.bicep' = {
  name: '${deployment().name}-sqldeploy'
  scope: az.resourceGroup(rgName)
  params: {
    adminLogin: keyVault.getSecret('sql-admin-acct')
    adminPassword: keyVault.getSecret('sql-admin-pwd')
    sqlServerName: '${resourceSuffix}-sqlserver-va'
    adminGroupOID: adminGroupOIDs[env]
    env: env
  }
  dependsOn: [ rg ]
}

module database_investc '../../IAC/Modules/Database/SQL/database.bicep' = {
  name: '${deployment().name}-db-investcDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    databaseName: '${resourceSuffix}-sqldatabase-va'
    sqlServerName: sqlServer.outputs.name
  }
}

module database_confluence '../../IAC/Modules/Database/SQL/database.bicep' = {
  name: '${deployment().name}-db-confluenceDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    databaseName: '${resourceSuffix}-sqldatabase-investc-confluence-va'
    sqlServerName: sqlServer.outputs.name
  }
}

