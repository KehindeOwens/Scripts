var keyVaultRgName = '${resourceSuffix}-rg'

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: '${resourceSuffix}-kv'
  scope: resourceGroup(keyVaultRgName)
}

module pubIP_appGateway '../../IAC/Modules/Network/publicIp.bicep' = {
  name: '${deployment().name}-pubIPDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-investcag-pubip-va'
     zones: []
  }
 }

module appGateway '../../IAC/Modules/Network/agw.bicep' = {
  name: '${deployment().name}-appGatewayDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-investcag-va'
    certificateName: 'investc-ui'
    keyVaultCertificateId: '${keyVault.properties.vaultUri}/secrets/investc-${env}-drlshrdev-appgw-cert'
    pubIpName: pubIP_appGateway.outputs.name
    umiName: managedIdentity.outputs.name
    vNetName: virtualNetwork.name
    backendAddressPools: [
      {
        name: 'investc-${env}-ui-va-beap'
        properties: {
          backendAddresses: [
            {
              fqdn: apps[0].outputs.fqdn
            }
          ]
        }
      }
      {
        name: 'investc-${env}-hd-v2-va-beap'
        properties: {
          backendAddresses: [
            {
              fqdn: apps[1].outputs.fqdn
            }
          ]
        }
      }
    ]
  }
}
