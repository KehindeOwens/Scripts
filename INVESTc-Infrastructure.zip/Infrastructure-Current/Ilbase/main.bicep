targetScope = 'subscription'

@description('The name of the containers to place in the storage account that hosts the application files.')
param containerNames array = [
  'announcementfiles'
  'batchreports'
  'dutytoinformfiles'
  'forumdocs'
  'inquiryfiles'
  'investcfiles'
  'librarydocs'
  'references'
  'remediationfiles'
  'tempfiles'
  'templates'
  'uploadedjson'
  'uploadedtemplates'
  'urlpdfs'
]

@description('The short name of the web apps to deploy. Defaults to empty array.')
param appNames array = [
  'dev'
  'dev-hd-v2'
  'api'
]
@description('The short name of the web apps to deploy. Defaults to empty array.')
param funcNames array = [
  'batch'
  'chrv'
  'match'
  'indivs'
  'units'
  'public'
  'rpt'
  'dcprocessing'
]
param env string
param region string

var resourceSuffix = 'investc-${env}'
var rgName = '${resourceSuffix}-ilbase-rg'
var vNetRG = '${resourceSuffix}-rg'
var vNetName = '${resourceSuffix}-vnet'

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2021-08-01' existing = {
  scope: resourceGroup(vNetRG)
  name: vNetName
}

module rg '../../IaC/Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgdeploy'
  params: {
    application: 'investc'
    region: region
    name: rgName
  }
}

module managedIdentity '../../IaC/Modules/Security/identity.bicep' = {
  name: '${deployment().name}-umideploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-apps-id'
  }
  dependsOn: [ rg ]
}

module roleAssignment_StorageBlobDataOwner '../../IaC/Modules/Security/roleAssignment.bicep' = {
  name: '${deployment().name}-roleassignmentdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    roleDefinitionId: 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b'
    umiName: managedIdentity.outputs.name
  }
}

module ase '../../IaC/Modules/Web/ase.bicep' = {
  name: '${deployment().name}-asedeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    name: '${resourceSuffix}-ilbase'
    vNetRG: vNetRG
    vNetName: virtualNetwork.name
    dnsSuffix: 'state.${env}'
    keyVaultReferenceIdentity: managedIdentity.outputs.id
    keyVaultName: '${resourceSuffix}-kv'
    subnetName: '${resourceSuffix}-ilbase-sn'
    umiAppId: managedIdentity.outputs.id
  }
}

module privateDNS_default '../../IAC/Modules/Network/privateDNS/dnsZone.bicep' = {
  name: '${deployment().name}-defaultprivdnsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${ase.outputs.name}.appserviceenvironment.net'
    ipv4Address: ase.outputs.internalInboundIpAddress
  }
  dependsOn: [ ase ]
}

module privateDNS_default_vnetLink '../../IAC/Modules/Network/privateDNS/dns-vnet-link.bicep' = {
  name: '${deployment().name}-defaultvnetlinkDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    dnsZoneName: privateDNS_default.outputs.name
    name: '${resourceSuffix}-vnetlink'
    vNetId: virtualNetwork.id
  }
}

module appInsights '../../IaC/Modules/Insights/appInsights.bicep' = {
  name: '${deployment().name}-appinsightsdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-appinsights'
  }
}

module asp_web '../../IaC/Modules/Web/asp.bicep' = {
  name: '${deployment().name}-aspwebdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    name: '${resourceSuffix}-asp'
    aseName: ase.outputs.name 
  }
}

module asp_func '../../IaC/Modules/Web/asp.bicep' = {
  name: '${deployment().name}-aspfuncdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    name: '${resourceSuffix}-asp-fa'
    aseName: ase.outputs.name
  }
}

module apps '../../IaC/Modules/Web/app.bicep' = [ for app in appNames: {
  name: '${deployment().name}-${app}-appsdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    appName: '${resourceSuffix}-${app}' // Change this for Dev. Names are Different
    appType: 'app'
    aseName: ase.outputs.name
    aspName: asp_web.outputs.name
    appInsightsConnectionString: appInsights.outputs.connection_string
    appInsightsId: appInsights.outputs.id
    appInsightsInstrumentationKey: appInsights.outputs.instrumentation_key
    dnsSuffix: privateDNS_default.outputs.name
    umiAppId: managedIdentity.outputs.id
    cors: ['*']
    appSettings: [
      {
        name: 'APPINSIGHTS_JAVASCRIPT_ENABLED'
        value: '1'
      }
      {
        name: 'AzureWebJobsStorage_accountName'
        value: storageAccount.outputs.name
      }
      {
        name: 'APPINSIGHTS_INSTRUMENTATIONKEY'
        value: appInsights.outputs.instrumentation_key
      }
    ]
  }
}]

module functions '../../IaC/Modules/Web/app.bicep' = [ for func in funcNames: {
  name: '${deployment().name}-${func}-funcsdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    appName: '${resourceSuffix}-${func}-fa'
    appType: 'functionapp'
    aseName: ase.outputs.name
    aspName: asp_func.outputs.name
    appInsightsConnectionString: appInsights.outputs.connection_string
    appInsightsId: appInsights.outputs.id
    appInsightsInstrumentationKey: appInsights.outputs.instrumentation_key
    dnsSuffix: privateDNS_default.outputs.name
    umiAppId: managedIdentity.outputs.id
    cors: [ '*' ]
    appSettings: [
      {
        name: 'APPINSIGHTS_JAVASCRIPT_ENABLED'
        value: '1'
      }
      {
        name: 'AzureWebJobsStorage_accountName'
        value: storageAccount.outputs.name
      }
      {
        name: 'APPINSIGHTS_INSTRUMENTATIONKEY'
        value: appInsights.outputs.instrumentation_key
      }
      {
        name: 'FUNCTIONS_EXTENSION_VERSION'
        value: '~4'
      }
      {
        name: 'AzureFunctionsWebHost__hostid'
        value: '${func}-fa'
      }
      {
        name: 'FUNCTIONS_WORKER_RUNTIME'
        value: 'dotnet'
      }
      {
        name: 'MSDEPLOY_RENAME_LOCKED_FILES'
        value: '1'
      }
      {
        name: 'WEBSITE_ENABLE_SYNC_UPDATE_SITE'
        value: 'true'
      }
      {
        name: 'WEBSITE_RUN_FROM_PACKAGE'
        value: '1'
      }
    ]
  }
}]

module signalR '../../IaC/Modules/SignalR/signalR.bicep' = {
  name: '${deployment().name}-signalrdeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-signalr'
    sku: 'Standard_S1'
  }
}

module storageAccount '../../IaC/Modules/Storage/StorageAccount/account.bicep' = {
  name: '${deployment().name}-storagedeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    name: 'investc${env}asesa'
    allowBlobPublicAccess: false
    allowedSubnetIds: [
      virtualNetwork.properties.subnets[0].id
      virtualNetwork.properties.subnets[1].id
      virtualNetwork.properties.subnets[2].id
    ]
  }
}

module storageAccount_datasava '../../IaC/Modules/Storage/StorageAccount/account.bicep' = {
  name: '${deployment().name}-appfiles-storagedeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    name: 'investc${env}datasava'
    allowBlobPublicAccess: false
    allowedSubnetIds: [
      virtualNetwork.properties.subnets[0].id
      virtualNetwork.properties.subnets[1].id
      virtualNetwork.properties.subnets[2].id
    ]
  }
}

module storageContainers '../../IaC/Modules/Storage/StorageAccount/container.bicep' = [ for container in containerNames: {
  name: '${deployment().name}-${container}-appfiles-storage-containers-deploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${container}'
    storageAccountName: storageAccount_datasava.outputs.name
  }
}]

