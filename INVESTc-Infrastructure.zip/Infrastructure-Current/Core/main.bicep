targetScope = 'subscription'

param baseTime string = utcNow('u')
param env string
param region string

var resourceSuffix = 'investc-${env}'
var rgName = '${resourceSuffix}-rg'
var vnetCidrPrefix = {
  dev: '10.20'
  stg: '10.50'
  tst: '10.40'
  prd: '10.30'
  dsr: '10.60'
}
var adminGroupOIDs = {
  dev: '264b06d2-fad3-474e-9061-6c587933fe82'
  stg: '777685a3-fc1a-4b69-ac2d-29839351357e'
  tst: '7f2c50bf-fc76-4dd6-890e-e611c7990202'
  prd: '4598d491-6f2f-4f55-ab75-8d1bfc833d21'
  dsr: '292df741-b280-474f-9772-05d98b8c0de7'
}
var readerGroupOIDs = {
  dev: 'c18e53e7-9f0a-4a1a-a83b-631b4e364829'
  stg: '905685fd-4478-419e-b6bd-9aa4c9bc73c1'
  tst: '550207f3-1f13-440f-93b8-cbb49a82d098'
  prd: '47b840d0-a0d9-442c-9421-4d02918fa40c'
  dsr: 'ed83a561-48d8-4c30-970c-1a9ed1e123d5'
}

module rg '../../IaC/Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgdeploy'
  params: {
    application: 'investc'
    region: region
    name: rgName
  }
}

module vNet '../../IaC/Modules/Network/VirtualNetwork/vnet.bicep'  = {
  name: '${deployment().name}-vnetdeploy'
  scope: resourceGroup(rgName)
  params: {
     addressPrefix: '${vnetCidrPrefix[env]}.0.0'
     addressSuffix: '16'
     vNetName: '${resourceSuffix}-vnet'
     subnets: [
      {
        name: 'investc-${env}-investcag-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.3.0/24'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
            'Microsoft.KeyVault'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-sd-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.4.0/24'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-rapid7-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.6.0/28'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-checkmarx-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.7.0/28'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-appgw-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.0.0/25'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'AzureBastionSubnet'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.5.0/27'
          networkSecurityGroup: {
            id: nsg_bastion.outputs.id
          }
          serviceEndpoints: [for service in []: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-admin-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.2.0/24'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-ilbase-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.0.128/25'
          delegations: [ 'Microsoft.Web/hostingEnvironments' ]
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
            'Microsoft.Sql'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
      {
        name: 'investc-${env}-devs-sn'
        properties: {
          addressPrefix: '${vnetCidrPrefix[env]}.8.0/24'
          serviceEndpoints: [for service in [
            'Microsoft.Storage'
          ]: {  
            service: service
            locations: '*'
          }]
          privateEndpointNetworkPolicies: 'Disabled'
          privateLinkServiceNetworkPolicies: 'Disabled'
        }
      }
     ]
   }
   dependsOn: [ rg ]
}

module keyVault '../../IaC/Modules/Security/KeyVault/vault.bicep'  = {
  name: '${deployment().name}-kvdeploy'
  scope: resourceGroup(rgName)
  params: {
    kvAdminGrpObjId: adminGroupOIDs[env]
    kvReaderGrpObjId: readerGroupOIDs[env]
    name: '${resourceSuffix}-kv'
   }
   dependsOn: [ vNet ]
}

module adminVMPwd '../../IaC/Modules/Security/generatePassword.bicep'  = {
  name: '${deployment().name}-vmpwddeploy'
  scope: az.resourceGroup(rgName)
  params: {
     utcValue: baseTime
   }
   dependsOn: [ rg ]
}

module keyVaultSecret '../../IaC/Modules/Security/KeyVault/secret.bicep'  = {
  name: '${deployment().name}-kvsecretdeploy'
  scope: az.resourceGroup(rgName)
  params: {
     kvName: keyVault.outputs.name
     secretName: 'vm-admin-pwd'
     secretValue: adminVMPwd.outputs.result
   }
   dependsOn: [ rg ]
}

module storageAccount_diag '../../IaC/Modules/Storage/StorageAccount/account.bicep'  = {
  name: '${deployment().name}-diagstoragedeploy'
  scope: az.resourceGroup(rgName)
  params: {
     name: 'investc${env}sadiag'
   }
   dependsOn: [ rg ]
}

module adminVM '../../IAC/Modules/Compute/VirtualMachines/windows.bicep' = {
  name: '${deployment().name}-admimVmDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    enableAcceleratedNetworking: false
    computerName: '${resourceSuffix}-vm'
    diagStorageAccountName: storageAccount_diag.outputs.name
    name: '${resourceSuffix}-vm'
    sku: '2016-Datacenter'
    subNetName: 'investc-dsr-admin-sn'
    vmPassword: adminVMPwd.outputs.result
    vmUsername: 'investc_admin'
    vNetName: vNet.outputs.name
  }
}

module pubIP_Bastion '../../IAC/Modules/Network/publicIp.bicep' = {
  name: '${deployment().name}-pubIPDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-bastion-ip'
     zones: []
  }
  dependsOn: [ rg ]
}

module bastion '../../IAC/Modules/Network/bastion.bicep' = {
  name: '${deployment().name}-bastionDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    bastionHostName: 'investc${env}bastion'
    pubIpName: pubIP_Bastion.outputs.name
    vNetName: vNet.outputs.name
  }
  dependsOn: [ pubIP_Bastion ]
}

module search '../../IaC/Modules/Search/search.bicep'  = {
  name: '${deployment().name}-searchdeploy'
  scope: resourceGroup(rgName)
  params: {
     name: '${resourceSuffix}-search'
   }
   dependsOn: [ rg ]
}

module nsg_bastion '../../IaC/Modules/Network/nsg.bicep'  = {
  name: '${deployment().name}-nsgbastiondeploy'
  scope: resourceGroup(rgName)
  params: {
     name: '${resourceSuffix}-bastion-nsg'
     securityRules: [
      {
        name: 'Outbound-HTTPS'
        type: 'Microsoft.Network/networkSecurityGroups/securityRules'
        properties: {
            protocol: '*'
            sourcePortRange: '*'
            destinationPortRange: '443'
            sourceAddressPrefix: '*'
            destinationAddressPrefix: 'AzureCloud'
            access: 'Allow'
            priority: 150
            direction: 'Outbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
        }
      }
      {
      name: 'Outbound-RDP'
      type: 'Microsoft.Network/networkSecurityGroups/securityRules'
      properties: {
          protocol: 'TCP'
          sourcePortRange: '*'
          destinationPortRange: '3389'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 140
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'Inbound-GatewayManager'
        type: 'Microsoft.Network/networkSecurityGroups/securityRules'
        properties: {
            protocol: '*'
            sourcePortRange: '*'
            destinationPortRange: '*'
            sourceAddressPrefix: 'GatewayManager'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 100
            direction: 'Inbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
         }
       }
       {
        name: 'Inbound-AzureCloud'
        type: 'Microsoft.Network/networkSecurityGroups/securityRules'
        properties: {
            protocol: '*'
            sourcePortRange: '*'
            destinationPortRange: '*'
            sourceAddressPrefix: 'AzureCloud'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 110
            direction: 'Inbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
          }
        }
        {
        name: 'Internet-Bastion'
        type: 'Microsoft.Network/networkSecurityGroups/securityRules'
        properties: {
            description: 'Allows Internet Access to Azure Bastion Host'
            protocol: 'TCP'
            sourcePortRange: '*'
            destinationPortRange: '443'
            sourceAddressPrefix: 'Internet'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 120
            direction: 'Inbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
          }
        }
        {
        name: 'Outbound-SSH'
        type: 'Microsoft.Network/networkSecurityGroups/securityRules'
        properties: {
            protocol: 'TCP'
            sourcePortRange: '*'
            destinationPortRange: '22'
            sourceAddressPrefix: '*'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 130
            direction: 'Outbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
          }
        }
      ]
    }
  }
     
   



