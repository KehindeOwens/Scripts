targetScope = 'subscription'

param env string
param region string

var resourceSuffix = 'investc-${env}'

module bluCore '../IaC/Blueprints/core.bicep' = {
  name: '${deployment().name}-coredeploy'
  params: {
    application: 'investc'
    env: env
    region: region
    rgName: '${resourceSuffix}-core-rg'
    allowedStorageIps: [ 
      {
        value: '73.106.244.24'
      }
    ]
  }
}

module bluApp '../IaC/Blueprints/apps.bicep' = {
  name: '${deployment().name}-appdeploy'
  params: {
    application: 'investc'
    env: env
    region: region
    rgName: '${resourceSuffix}-apps-rg'
    vNetId: bluCore.outputs.vnetId
    appNames: [
      'ui'
      'api'
    ]
    funcNames: [
      'batch'
      'match'
      'indivs'
      'units'
      'public'
      'rpt'
      'dcprocessing'
     ]
    allowedStorageIps: [
      {
        value: '108.252.211.86'
        action: 'Allow'
      }
    ]
  }
  dependsOn: [ bluCore ]
}

module bluAgw '../IaC/Blueprints/agw.bicep' = {
  name: '${deployment().name}-agwdeploy'
  params: {
    application: 'investc'
    env: env
    region: region
    rgName: bluApp.outputs.rg_name
    keyVaultCertificateId: '${bluCore.outputs.opsKeyVaultUrl}/secrets/investc-ui'
    vNetName: bluCore.outputs.vnetName
    backendAddressPools: [
      {
        name: '${bluApp.outputs.webapp_api_name}-beap'
        properties: {
          backendAddresses: [
            {
              fqdn: '${bluApp.outputs.webapp_api_name}.${bluApp.outputs.ase_name}.appserviceenvironment.net'
            }
          ]
        }
      }
      {
        name: '${bluApp.outputs.webapp_ui_name}-beap'
        properties: {
          backendAddresses: [
            {
              fqdn: '${bluApp.outputs.webapp_ui_name}.${bluApp.outputs.ase_name}.appserviceenvironment.net'
            }
          ]
        }
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: '${bluApp.outputs.webapp_api_name}-http'
        properties: {
          port: 80
          protocol: 'Http'
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: true
          affinityCookieName: 'ApplicationGatewayAffinity'
          requestTimeout: 120
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_api_name}-probe')
          }
        }
      }
      {
        name: '${bluApp.outputs.webapp_ui_name}-http'
        properties: {
          port: 80
          protocol: 'Http'
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: true
          affinityCookieName: 'ApplicationGatewayAffinity'
          requestTimeout: 120
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_ui_name}-probe')
          }
        }
      }
    ]
    healthProbes: [
      {
        name: '${bluApp.outputs.webapp_api_name}-probe'
        properties: {
          protocol: 'Http'
          host: '${bluApp.outputs.webapp_api_name}.${bluApp.outputs.ase_name}.appserviceenvironment.net'
          path: '/'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: false
          minServers: 0
          match: {
            statusCodes: [
              '200-399'
            ]
          }
        }
      }
      {
        name: '${bluApp.outputs.webapp_ui_name}-probe'
        properties: {
          protocol: 'Http'
          host: '${bluApp.outputs.webapp_ui_name}.${bluApp.outputs.ase_name}.appserviceenvironment.net'
          path: '/'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: false
          minServers: 0
          match: {
            statusCodes: [
              '200-399'
            ]
          }
        }
      }
    ]
    urlPathMaps: [
      {
        name: bluApp.outputs.webapp_ui_name
        properties: {
          defaultBackendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_ui_name}-beap')
          }
          defaultBackendHttpSettings: {
            id: resourceId('Microsoft.Network/applicationGateways/backendHttpSettingsCollection/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_ui_name}-http')
          }
          pathRules: [
            {
              name: bluApp.outputs.webapp_api_name
              properties: {
                paths: [
                  '/api*'
                ]
                backendAddressPool: {
                  id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_api_name}-beap')
                }
                backendHttpSettings: {
                  id: resourceId('Microsoft.Network/applicationGateways/backendHttpSettingsCollection/', '${resourceSuffix}-agw', '${bluApp.outputs.webapp_api_name}-http')
                }
              }
            }
          ]
        }
      }
    ]
   requestRoutingRules: [
      {
        name: '${resourceSuffix}-ui-rule'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 10
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners/', '${resourceSuffix}-agw', '${resourceSuffix}-listener')
          }
          urlPathMap: {
            id: resourceId('Microsoft.Network/applicationGateways/urlPathMaps/', '${resourceSuffix}-agw', bluApp.outputs.webapp_ui_name)
          }
        }
      }
    ]
  }
  dependsOn: [ bluApp ]
}

