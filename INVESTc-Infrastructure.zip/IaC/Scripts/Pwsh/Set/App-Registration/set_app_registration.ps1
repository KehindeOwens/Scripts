param(
$displayName = $env:displayName,
    
$dataServiceAppId = $env:dataServiceAppId,
    
$ResourceScopeId = $env:ResourceScopeId 
)

# Create INVESTc AppRole objects
$superUserRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$superUserRole.DisplayName = "SuperUser Role"
$superUserRole.Description = "SuperUser role indicator"
$superUserRole.Value = "R00"
$superUserRole.Id = "538f94d9-b1e3-4fee-b905-f9b795751b69"
$superUserRole.IsEnabled = (-not $Disabled)
$superUserRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$helpDeskRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$helpDeskRole.DisplayName = "Help Desk Role"
$helpDeskRole.Description = "Help Desk Role indicator"
$helpDeskRole.Value = "R01"
$helpDeskRole.Id = "ed5798e1-d9b3-47a0-ba76-75d360a324b5"
$helpDeskRole.IsEnabled = (-not $Disabled)
$helpDeskRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$advisorRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$advisorRole.DisplayName = "Advisor baseline Role"
$advisorRole.Description = "Advisor baseline role indicator"
$advisorRole.Value = "R31"
$advisorRole.Id = "19061e5b-94f8-4b52-8c71-076b3e3daab5"
$advisorRole.IsEnabled = (-not $Disabled)
$advisorRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$postSubmitterRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$postSubmitterRole.DisplayName = "Post Submitter Role"
$postSubmitterRole.Description = "Post Submitter baseline role indicator"
$postSubmitterRole.Value = "R11"
$postSubmitterRole.Id = "43986226-77aa-490c-8e39-467d67ebf5bf"
$postSubmitterRole.IsEnabled = (-not $Disabled)
$postSubmitterRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$postVetterRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$postVetterRole.DisplayName = "Post Vetter Role"
$postVetterRole.Description = "Post Vetter baseline role indicator"
$postVetterRole.Value = "R12"
$postVetterRole.Id = "c410bd80-b3cc-42ad-8800-69bc9a89cc54"
$postVetterRole.IsEnabled = (-not $Disabled)
$postVetterRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$ogaVetterRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$ogaVetterRole.DisplayName = "OGA Vetter Role"
$ogaVetterRole.Description = "OGA Vetter baseline role indicator"
$ogaVetterRole.Value = "R13"
$ogaVetterRole.Id = "f05df48c-8841-4c05-b108-d8163b07cb8a"
$ogaVetterRole.IsEnabled = (-not $Disabled)
$ogaVetterRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$postSupervisorRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$postSupervisorRole.DisplayName = "Post Supervisor Role"
$postSupervisorRole.Description = "Post Supervisor baseline role indicator"
$postSupervisorRole.Value = "R10"
$postSupervisorRole.Id = "9ca7ba64-1611-4683-b33d-61a3e9da7abc"
$postSupervisorRole.IsEnabled = (-not $Disabled)
$postSupervisorRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$readerRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$readerRole.DisplayName = "Reader baseline Role"
$readerRole.Description = "Reader baseline role indicator"
$readerRole.Value = "R41"
$readerRole.Id = "9bd6d25c-8643-4719-8955-8c9727b2f91b"
$readerRole.IsEnabled = (-not $Disabled)
$readerRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$submitterplusRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$submitterplusRole.DisplayName = "Submitter+ baseline Role"
$submitterplusRole.Description = "Submitter+ baseline role indicator"
$submitterplusRole.Value = "R14"
$submitterplusRole.Id = "538f940c-b1e3-4fee-b905-f9b795751b69"
$submitterplusRole.IsEnabled = (-not $Disabled)
$submitterplusRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$drlVetterRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$drlVetterRole.DisplayName = "DC Vetter (DRL) Role"
$drlVetterRole.Description = "DC Vetter (DRL) baseline role indicator"
$drlVetterRole.Value = "R21"
$drlVetterRole.Id = "35d253d9-f609-4120-996f-180aaae53af8"
$drlVetterRole.IsEnabled = (-not $Disabled)
$drlVetterRole.AllowedMemberTypes = "User"
#----------------------------------------------------------
$regVetterRole = [Microsoft.Open.AzureAD.Model.AppRole]::new()
$regVetterRole.DisplayName = "DC Vetter (REG) Role"
$regVetterRole.Description = "DC Vetter (REG) baseline role indicator"
$regVetterRole.Value = "R22"
$regVetterRole.Id = "dbd4cac8-9c32-49d1-ba48-db5fffe8452e"
$regVetterRole.IsEnabled = (-not $Disabled)
$regVetterRole.AllowedMemberTypes = "User"

# Add AppRoles and Required Resource Access to App Reg
$appRoles = ($superUserRole , $helpDeskRole , $advisorRole , $postSubmitterRole , $postVetterRole , $ogaVetterRole , $postSupervisorRole , $readerRole, $submitterplusRole , $drlVetterRole , $regVetterRole )
#
#----------------------------------------------------------
#----------------------------------------------------------
#

# Create Required Resource Object
$dataServiceAccess = [Microsoft.Open.AzureAD.Model.RequiredResourceAccess]@{
    ResourceAppId = $dataServiceAppId;
    ResourceAccess =
        [Microsoft.Open.AzureAD.Model.ResourceAccess]@{
            Id = $ResourceScopeId;
            Type = "Scope"}
}

# Get App Reg Object from Azure Active Directory
$app = (Get-AzureADApplication -Filter "identifierUris/any(uri:uri eq 'api://$displayName')")

# Create Extension Property on App Reg
New-AzureADApplicationExtensionProperty -ObjectId  $app.ObjectId `
                                        -DataType "string" `
                                        -Name "SecondaryRole" `
                                        -TargetObjects "User" 

Start-Sleep -Seconds 5

# Get Name of Newly Created Extension Property
$claimname = (Get-AzureADApplicationExtensionProperty -ObjectId $app.ObjectId).Name

# Create Parameter for Optional Claims
$claims = @{ IdToken = [Microsoft.Open.AzureAD.Model.OptionalClaim]@{ Name = $claimname; Source = "user" } ; AccessToken = [Microsoft.Open.AzureAD.Model.OptionalClaim]@{ Name = $claimname; Source = "user" } } 

# Update App Reg with Optional Claims, App Roles, & API Permissions
Set-AzureADApplication -ObjectId $app.ObjectId `
                       -AppRoles $appRoles `
                       -RequiredResourceAccess $dataServiceAccess `
                       -OptionalClaims $claims




