param(
$displayName = $env:displayName,
    
$env_abbr = $env:env_abbr
)

# Get Groups from AAD to add to Enterprise Application
$Advisor        = (Get-AzureADGroup -SearchString "investc-$env_abbr-advisor")
$DRLVetter      = (Get-AzureADGroup -SearchString "investc-$env_abbr-dcvetter-drl")
$RegVetter      = (Get-AzureADGroup -SearchString "investc-$env_abbr-dcvetter-reg")
$OGAVetter      = (Get-AzureADGroup -SearchString "investc-$env_abbr-ogavetter")
$HelpDesk       = (Get-AzureADGroup -SearchString "investc-$env_abbr-helpdesk")
$PostSubmitter  = (Get-AzureADGroup -SearchString "investc-$env_abbr-postsubmitter")
$PostSupervisor = (Get-AzureADGroup -SearchString "investc-$env_abbr-postsupervisor")
$PostVetter     = (Get-AzureADGroup -SearchString "investc-$env_abbr-postvetter")
$Reader         = (Get-AzureADGroup -SearchString "investc-$env_abbr-reader")
$Submitterplus  = (Get-AzureADGroup -SearchString "investc-$env_abbr-submitter")
$SuperUser      = (Get-AzureADGroup -SearchString "investc-$env_abbr-superuser")

# Get App Reg Object from Azure Active Directory
$app = (Get-AzureADApplication -Filter "identifierUris/any(uri:uri eq 'api://$displayName')")

# Get Enterprise Application Object from Azure Active Directory
$sp = (Get-AzureADServicePrincipal -All $true | Where-Object {$_.AppId -eq $app.AppId})

# Add Dynamic Groups to Enterprise Application - All Roles should be applied to Application 
New-AzureADGroupAppRoleAssignment -ObjectId $Submitterplus.ObjectId  -PrincipalId $Submitterplus.ObjectId  -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R14" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $PostSubmitter.ObjectId  -PrincipalId $PostSubmitter.ObjectId  -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R11" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $PostVetter.ObjectId     -PrincipalId $PostVetter.ObjectId     -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R12" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $OGAVetter.ObjectId      -PrincipalId $OGAVetter.ObjectId      -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R13" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $PostSupervisor.ObjectId -PrincipalId $PostSupervisor.ObjectId -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R10" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $DRLVetter.ObjectId      -PrincipalId $DRLVetter.ObjectId      -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R21" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $RegVetter.ObjectId      -PrincipalId $RegVetter.ObjectId      -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R22" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $Advisor.ObjectId        -PrincipalId $Advisor.ObjectId        -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R31" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $Reader.ObjectId         -PrincipalId $Reader.ObjectId         -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R41" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $HelpDesk.ObjectId       -PrincipalId $HelpDesk.ObjectId       -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R01" }).Id
New-AzureADGroupAppRoleAssignment -ObjectId $SuperUser.ObjectId      -PrincipalId $SuperUser.ObjectId      -ResourceId $sp.ObjectId -Id ($sp.AppRoles | Where-Object { $_.Value -eq "R00" }).Id