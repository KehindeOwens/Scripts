param(
    [Parameter(Mandatory=$true, Position=0)]
    [string] $resourceGroupName,

    [Parameter(Mandatory=$true, Position=1)]
    [string] $automationAccountName   
)

# Login to Azure Resource Management portal
Write-Host "Checking context...";
$context = Get-AzContext
if($null -ne $context){
  if(!(($context.Subscription.TenantId -match $tenant_Id) -and ($context.Subscription.Id -match $subscription_Id))){
    do{
      Remove-AzAccount -ErrorAction SilentlyContinue | Out-Null
      $context = Get-AzContext
      }
    until($null -eq $context)
    Connect-AzAccount -EnvironmentName $environmentName -TenantId $tenant_Id -Subscription $subscription_Id
    }
  }
else{
  Connect-AzAccount -EnvironmentName $environmentName -TenantId $tenant_Id -Subscription $subscription_Id
}

# Set time of Automation Schedule
$TimeZone = ([System.TimeZoneInfo]::Local).Id
$StartTime = Get-Date "19:00:00"
  
# Get Automation Account
$aa = (Get-AzAutomationAccount -ResourceGroupName $resourceGroupName -Name $automationAccountName)

# Import Runbook 
Import-AzAutomationRunbook -ResourceGroupName $aa.ResourceGroupName -AutomationAccountName $aa.AutomationAccountName -Path '<path of runbook script>' -Type PowerShellWorkflow -Published 

# Create Runbook Schedule
New-AzAutomationSchedule -ResourceGroupName $aa.ResourceGroupName -AutomationAccountName $aa.AutomationAccountName -Name "<automation account schedule name>" -TimeZone $TimeZone -StartTime $StartTime -DayInterval 14 

# Import Posh-ACME Module
New-AzAutomationModule -ResourceGroupName $aa.ResourceGroupName -AutomationAccountName $aa.AutomationAccountName -Name "<automation account module name>" -ContentLink "<https link of downloadable module link>" 
