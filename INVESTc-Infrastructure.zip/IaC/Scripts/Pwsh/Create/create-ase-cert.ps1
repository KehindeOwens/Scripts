# Generate random password as a SecureString

$password = -join ([char[]]"!@#$%^&*0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz" |Get-Random -Count 10)

$SecureStringPassword = ConvertTo-SecureString -String $password -AsPlainText -Force
Return $SecureStringPassword

# Set script execution folder
Set-Location $PSScriptRoot

# Variables
$tenant_Id = "< Tenant ID >"
$subscription_Id = "< Subscription ID >"
$projectPrefix = "< investc or hrg >"
$envIdentifier = "<env abbreviation>"
$kvName = "$projectPrefix-$envIdentifier-kv"
$kvCertName = "ase-cert"
$kvCertKeyName = "ase-cert-pwd"
$aseCertPFXFile = "ase-cert.pfx"
$environmentName = 'AzureCloud'

# Login to Azure Resource Management portal
Write-Host "Checking context...";
$context = Get-AzContext
if($null -ne $context){
  if(!(($context.Subscription.TenantId -match $tenant_Id) -and ($context.Subscription.Id -match $subscription_Id))){
    do{
      Remove-AzAccount -ErrorAction SilentlyContinue | Out-Null
      $context = Get-AzContext
      }
    until($null -eq $context)
    Connect-AzAccount -EnvironmentName $environmentName -TenantId $tenant_Id -Subscription $subscription_Id
    }
  }
else{
  Connect-AzAccount -EnvironmentName $environmentName -TenantId $tenant_Id -Subscription $subscription_Id
  }

# Create Self Signed Cert for ASE
$aseCert = New-SelfSignedCertificate `
  -certstorelocation cert:\currentuser\my `
  -dnsname "*.state.$envIdentifier", "*.scm.state.$envIdentifier"

$cert = Get-ChildItem -path cert:\currentuser\my\$($aseCert.Thumbprint)
Export-PfxCertificate `
  -Cert $cert `
  -FilePath .\$aseCertPFXFile `
  -Password $SecureStringPassword

# Store cert in Key Vault
Import-AzKeyVaultCertificate -VaultName $kvName -Name $kvCertName -FilePath "C:\Windows\System32\ase-cert.pfx" -Password $SecureStringPassword

# Store cert password in Key Vault
Set-AzKeyVaultSecret -VaultName $kvName -Name $kvCertKeyName -SecretValue $SecureStringPassword