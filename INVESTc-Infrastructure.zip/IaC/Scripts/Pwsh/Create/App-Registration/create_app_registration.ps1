param(
    [Parameter(Mandatory=$true, Position=0)]
    [string] $displayName,

    [Parameter(Mandatory=$true, Position=1)]
    [string] $homePageUrl   
)

$replyUrls = @( $homePageUrl, "${homePageUrl}/.auth/login/aad*", "${homePageUrl}/.auth/login/aad/callback" )


# Create app registration 
New-AzureADApplication -DisplayName $displayName `
                       -Homepage $homePageUrl `
                       -ReplyUrls $replyUrls `
                       -IdentifierUris "api://${displayName}" `
                       -Oauth2AllowImplicitFlow $true `
                       -Oauth2AllowUrlPathMatching $true `
                       -AvailableToOtherTenants $false
                       
# Get app reg attributes
$app = (Get-AzureADApplication -Filter "identifierUris/any(uri:uri eq 'api://${displayName}')")

# Create Client Secret on App Reg
New-AzureADApplicationPasswordCredential -ObjectId $app.ObjectId `
                                         -CustomKeyIdentifier "client_secret" 
# Create Service Principal for App Reg
New-AzureADServicePrincipal -AccountEnabled $true -AppId $app.AppId
