param(
    [Parameter(Mandatory=$true, Position=0)]
    [string] $displayName,

    [Parameter(Mandatory=$true, Position=1)]
    [string] $homePageUrl   
)

# Login to Azure AD PowerShell With Admin Account
Connect-AzureAD 

# Get App Registration
$app = (Get-AzureADApplication -Filter "identifierUris/any(uri:uri eq 'api://${displayName}')")

# Create the self signed cert
$currentDate = Get-Date
$endDate = $currentDate.AddYears(1)
$notAfter = $endDate.AddYears(1)
$pwd = "<password>"
$thumb = (New-SelfSignedCertificate -CertStoreLocation cert:\localmachine\my -DnsName com.foo.bar -KeyExportPolicy Exportable -Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" -NotAfter $notAfter).Thumbprint
$pwd = ConvertTo-SecureString -String $pwd -Force -AsPlainText
Export-PfxCertificate -cert "cert:\localmachine\my\$thumb" -FilePath c:\temp\examplecert.pfx -Password $pwd

# Load the certificate
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate("C:\Users\Kehinde\cert.pfx", $pwd)
$keyValue = [System.Convert]::ToBase64String($cert.GetRawCertData())

# Set the App Registration Key 
New-AzureADApplicationKeyCredential -ObjectId $app.ObjectId -CustomKeyIdentifier $thumb -StartDate $currentDate -EndDate $endDate -Type AsymmetricX509Cert -Usage Verify -Value $keyValue