targetScope = 'subscription'

@description('The application being deployed. Allowed options are investc or hrg.')
@allowed([
  'investc'
  'hrg'
])
param application string

@description('Backend address pool of the application gateway resource.')
param backendAddressPools array = []

@description('Backend http settings of the application gateway resource.')
param backendHttpSettingsCollection array = []

@description('The azure subscription/environment that the resource will be deployed to. Param is asking for the sub acronym not the full name.')
@allowed([
  'dev'
  'stg'
  'tst'
  'prd'
  'qa'
  'dsr'
])
param env string

@description('Probes of the application gateway resource.')
param healthProbes array = []

@description('Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in KeyVault. Format is https://vaultname.vault.azure.net/secrets/certificatename.')
param keyVaultCertificateId string

@description('The region that the resource will be deployed to. Default is eastus; westus is only used for the disaster recovery environment.')
@allowed([
  'eastus'
  'westus'
])
param region string = 'eastus'

@description('Request routing rules of the application gateway resource.')
param requestRoutingRules array = []

@description('The name of the resource group to deploy the app resources in.')
param rgName string

@description('The Resource Id of the Subscription Virtual Network.')
param vNetName string

@description('URL path map of the application gateway resource.')
param urlPathMaps array = []

var hostNameLookUp = {
  dev: 'drlshrdev.drlteam.net'
  stg: 'drlshrstg.drlteam.net'
  tst: 'drlshr.drlteam.net'
  prd: 'drlshr.state.gov'
  dsr: 'drlshrdsr.drlteam.net'
}
var hostname = hostNameLookUp[env]

var resourceSuffix = '${application}-${env}'

module agw_id '../Modules/Security/identity.bicep' = {
  name: '${deployment().name}-umiDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-agw-id'
    region: region
  }
}

module pubIP '../Modules/Network/publicIp.bicep' = {
  name: '${deployment().name}-pipDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-agw-pip'
    region: region
  }
  dependsOn: [ agw_id ]
}

module agw '../Modules/Network/agw.bicep' = {
  name: '${deployment().name}-agwDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    keyVaultCertificateId: keyVaultCertificateId  
    certificateName: '${resourceSuffix}-ui'
    name: '${resourceSuffix}-agw'
    pubIpName: pubIP.outputs.name
    umiName: agw_id.outputs.name
    vNetName: vNetName
    httplistener: [
      {
        name: '${resourceSuffix}-listener'
        properties: {
          frontendIPConfiguration: {
            id: resourceId('Microsoft.Network/applicationGateways/frontendIPConfigurations/', '${resourceSuffix}-agw', 'agw-pip')
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontendPorts/', '${resourceSuffix}-agw', 'agw-feport')
          }
          protocol: 'Https'
          sslCertificate: {
            id: resourceId('Microsoft.Network/applicationGateways/sslCertificates/', '${resourceSuffix}-agw', '${application}-ui')
          }
          hostName: hostname
          hostNames: []
          requireServerNameIndication: true
        }
      }
    ]
    backendAddressPools: backendAddressPools
    backendHttpSettingsCollection: backendHttpSettingsCollection
    healthProbes: healthProbes
    urlPathMaps: urlPathMaps
    requestRoutingRules: requestRoutingRules
  }
  dependsOn: [ pubIP ]
}

output agw_id_name string = agw_id.outputs.name
output agw_id_id string = agw_id.outputs.id
output agw_name string = agw.outputs.name
output agw_id string = agw.outputs.id
output pip_name string = pubIP.outputs.name
output pip_id string = pubIP.outputs.id

