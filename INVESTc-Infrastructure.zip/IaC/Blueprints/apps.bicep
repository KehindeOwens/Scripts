targetScope = 'subscription'

@description('The individual IPs allowed access to the core storage accounts (main and diagnostic). Defaults to an empty array.')
param allowedStorageIps array = []

@description('Indicates the virtual network(s) and nested subnets that are allowed access to the storage account. Defaults to an empty array')
param allowedSubnetIds array = []

@description('The application being deployed. Allowed options are investc or hrg.')
@allowed([
  'investc'
  'hrg'
])
param application string

@description('The short name of the web apps to deploy. Defaults to empty array.')
param appNames array = []

@description('The azure subscription/environment that the resource will be deployed to. Param is asking for the sub acronym not the full name.')
@allowed([
  'dev'
  'stg'
  'tst'
  'prd'
  'qa'
  'dsr'
])
param env string

@description('The short name of the function apps to deploy. Defaults to empty array.')
param funcNames array = []

@description('The name of the resource group to deploy the app resources in.')
param rgName string

@description('The region that the resource will be deployed to. Default is eastus; westus is only used for the disaster recovery environment.')
@allowed([
  'eastus'
  'westus'
])
param region string = 'eastus'

@description('The resource ID of the environment virtual network.')
param vNetId string

var resourceSuffix = '${application}-${env}'

module resourceGroup '../Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgDeploy'
  params: {
    application: application
    name: rgName
    region: region
  }
}

module app_id '../Modules/Security/identity.bicep' = {
  name: '${deployment().name}-umiDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-apps-id'
    region: region
  }
  dependsOn: [ resourceGroup ]
}

module appInsights '../Modules/Insights/appInsights.bicep' = {
  name: '${deployment().name}-appInsightsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-appinsights'
  }
  dependsOn: [ resourceGroup ]
}

module ase '../Modules/Web/ase.bicep' = {
  name: '${deployment().name}-aseDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-ase'
    vNetName: '${resourceSuffix}-vnet'
    vNetRG: '${resourceSuffix}-core-rg'
  }
  dependsOn: [ resourceGroup ]
}

module privateDNS_default '../Modules/Network/privateDNS/dnsZone.bicep' = {
  name: '${deployment().name}-defaultprivdnsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${ase.outputs.name}.appserviceenvironment.net'
    ipv4Address: ase.outputs.internalInboundIpAddress
  }
  dependsOn: [ ase ]
}

module privateDNS_default_vnetLink '../Modules/Network/privateDNS/dns-vnet-link.bicep' = {
  name: '${deployment().name}-defaultvnetlinkDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    dnsZoneName: privateDNS_default.outputs.name
    name: '${application}-${env}-vnetlink'
    vNetId: vNetId
  }
  dependsOn: [ resourceGroup ]
}

module privateDNS_custom '../Modules/Network/privateDNS/dnsZone.bicep' = {
  name: '${deployment().name}-customprivdnsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: 'state.${env}'
    ipv4Address: ase.outputs.internalInboundIpAddress
  }
  dependsOn: [ ase ]
}

module privateDNS_custom_vnetLink '../Modules/Network/privateDNS/dns-vnet-link.bicep' = {
  name: '${deployment().name}-customvnetlinkDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    dnsZoneName: privateDNS_custom.outputs.name
    name: '${application}-${env}-vnetlink'
    vNetId: vNetId
  }
  dependsOn: [ resourceGroup ]
}

module asp_apps '../Modules/Web/asp.bicep' = {
  name: '${deployment().name}-asp-apps-Deploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-asp-web'
    aseName: ase.outputs.name
  }
  dependsOn: [ ase ]
}

module asp_funcs '../Modules/Web/asp.bicep' = {
  name: '${deployment().name}-asp-funcs-Deploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-asp-func'
    aseName: ase.outputs.name
  }
  dependsOn: [ ase ]
}

module webApps '../Modules/Web/app.bicep' = [ for app in appNames: {
  name: '${app}-Deploy'
  scope: az.resourceGroup(rgName)
  params: {
    appName: '${resourceSuffix}-${app}'
    appType: 'app'
    aseName: ase.outputs.name
    aspName: asp_apps.outputs.name
    dnsSuffix: privateDNS_default.outputs.name
    umiAppId: app_id.outputs.id
  }
  dependsOn: [ asp_apps ]
}]

module funcApps '../Modules/Web/app.bicep' = [ for func in funcNames: {
  name: '${func}-Deploy'
  scope: az.resourceGroup(rgName)
  params: {
    appName: '${resourceSuffix}-${func}-func'
    appType: 'functionapp'
    aseName: ase.outputs.name
    aspName: asp_funcs.outputs.name
    dnsSuffix: privateDNS_default.outputs.name
    umiAppId: app_id.outputs.id
  }
  dependsOn: [ asp_funcs ]
}]

module signalR '../Modules/SignalR/signalR.bicep' = {
  name: '${deployment().name}-signalrDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-signalr'
    sku: 'Standard_S1'
  }
  dependsOn: [ resourceGroup ]
}

module storageAccount_apps '../Modules/Storage/StorageAccount/account.bicep' = {
  name: '${deployment().name}-storageMainDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${application}${env}appst'
    skuType: 'Standard_GRS'
    allowBlobPublicAccess: false
    malwareScanningEnabled: true
    minimumTlsVersion: 'TLS1_2'
    allowedIPaddresses: allowedStorageIps
    allowedSubnetIds: allowedSubnetIds
  }
}

output ase_name string = ase.outputs.name
output ase_id string = ase.outputs.id
output rg_name string = resourceGroup.outputs.name
output rg_id string = resourceGroup.outputs.id
output webapp_ui_name string = webApps[0].outputs.name
output webapp_api_name string = webApps[1].outputs.name


