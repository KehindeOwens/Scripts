targetScope = 'subscription'
/**/
@description('The individual IPs allowed access to the core storage accounts (main and diagnostic). Defaults to an empty array.')
param allowedStorageIps array = []

@description('The application being deployed. Allowed options are investc or hrg.')
@allowed([
  'investc'
  'hrg'
])
param application string

@description('The azure subscription/environment that the resource will be deployed to. Param is asking for the sub acronym not the full name.')
@allowed([
  'dev'
  'stg'
  'tst'
  'prd'
  'qa'
  'dsr'
])
param env string

@description('The name of the resource group to deploy the core resources in.')
param rgName string

@description('The region that the resource will be deployed to. Default is eastus; westus is only used for the disaster recovery environment.')
@allowed([
  'eastus'
  'westus'
])
param region string = 'eastus'
//**//
var resourceSuffix = '${application}-${env}'

var vNetCidrsPrefixes = {
  dev: '10.20'
  stg: '10.50'
  tst: '10.40'
  prd: '10.30'
  qa: '10.60'
  dsr: '10.70'
}
var subscriptionVnet = vNetCidrsPrefixes[env]
var vNetCidrPrefix = '${subscriptionVnet}.0.0'
var subNetOpsCidrPrefix = '${subscriptionVnet}.0.0'
var subNetAseCidrPrefix = '${subscriptionVnet}.0.64'
var subNetAgwCidrPrefix = '${subscriptionVnet}.0.32'
var subNetBastionCidrPrefix = '${subscriptionVnet}.0.128'
var subNetServiceDeskCidrPrefix = '${subscriptionVnet}.0.48'

var kvAdminGroupObjIds = {
  dev: '264b06d2-fad3-474e-9061-6c587933fe82'
  stg: '777685a3-fc1a-4b69-ac2d-29839351357e'
  tst: '7f2c50bf-fc76-4dd6-890e-e611c7990202'
  prd: '4598d491-6f2f-4f55-ab75-8d1bfc833d21'
  qa: '50edf145-cb5a-4067-a064-e97b5422c034'
  dsr: '292df741-b280-474f-9772-05d98b8c0de7'
}
var subscriptionkvAdminGroup = kvAdminGroupObjIds[env]

var kvReaderGroupObjIds = {
  dev: 'c18e53e7-9f0a-4a1a-a83b-631b4e364829'
  stg: '905685fd-4478-419e-b6bd-9aa4c9bc73c1'
  tst: '550207f3-1f13-440f-93b8-cbb49a82d098'
  prd: '47b840d0-a0d9-442c-9421-4d02918fa40c'
  qa: 'c74509ab-e381-4c64-acc2-68e15dc5bb24'
  dsr: 'ed83a561-48d8-4c30-970c-1a9ed1e123d5'
}
var subscriptionVKvReaderGroup = kvReaderGroupObjIds[env]
//**//
module resourceGroup '../Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgDeploy'
  params: {
    application: application
    name: rgName
    region: region
  }
}

module virtualNetwork '../Modules/Network/VirtualNetwork/vnet.bicep' = {
  name: '${deployment().name}-vnetDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    addressPrefix: vNetCidrPrefix
    vNetName: '${resourceSuffix}-vnet'
    subnets: [
      {
        name: 'ops'
        properties: {
          addressPrefix: '${subNetOpsCidrPrefix}/27'
          networkSecurityGroup: {
            id: networkSecurityGroup_ops.outputs.id
          }
          serviceEndpoints: [
            {
              service: 'Microsoft.Sql'
              locations: [
                'eastus'
              ]
            }
            {
              service: 'Microsoft.Storage'
              locations: [
                'eastus'
                'westus'
              ]
            }
          ]
          delegations: []
          privateEndpointNetworkPolicies: 'Enabled'
          privateLinkServiceNetworkPolicies: 'Enabled'
        }
        type: 'Microsoft.Network/virtualNetworks/subnets'
      }
      {
        name: 'ilbase'
        properties: {
          addressPrefix: '${subNetAseCidrPrefix}/26'
          networkSecurityGroup: {
            id: networkSecurityGroup_ilbase.outputs.id
          }
          serviceEndpoints: [
            {
              service: 'Microsoft.Sql'
              locations: [
                'eastus'
              ]
            }
            {
              service: 'Microsoft.Storage'
              locations: [
                'eastus'
                'westus'
              ]
            }
          ]
          delegations: [
            {
              name: 'Microsoft.Web.hostingEnvironments'
              properties: {
                serviceName: 'Microsoft.Web/hostingEnvironments'
              }
              type: 'Microsoft.Network/virtualNetworks/subnets/delegations'
            }
          ]
          privateEndpointNetworkPolicies: 'Enabled'
          privateLinkServiceNetworkPolicies: 'Enabled'
        }
        type: 'Microsoft.Network/virtualNetworks/subnets'
      }
      {
        name: 'agw'
        properties: {
          addressPrefix: '${subNetAgwCidrPrefix}/28'
          networkSecurityGroup: {
            id: networkSecurityGroup_agw.outputs.id
          }
          serviceEndpoints: [
            {
              service: 'Microsoft.Storage'
              locations: [
                'eastus'
                'westus'
              ]
            }
          ]
          delegations: []
          privateEndpointNetworkPolicies: 'Enabled'
          privateLinkServiceNetworkPolicies: 'Enabled'
        }
        type: 'Microsoft.Network/virtualNetworks/subnets'
      }
      {
        name: 'servicedesk'
        properties: {
          addressPrefix: '${subNetServiceDeskCidrPrefix}/28'
          networkSecurityGroup: {
            id: networkSecurityGroup_sd.outputs.id
          }
          serviceEndpoints: []
          delegations: []
          privateEndpointNetworkPolicies: 'Enabled'
          privateLinkServiceNetworkPolicies: 'Enabled'
        }
        type: 'Microsoft.Network/virtualNetworks/subnets'
      }
      {
        name: 'AzureBastionSubnet'
        properties: {
          addressPrefix: '${subNetBastionCidrPrefix}/26'
          networkSecurityGroup: {
            id: networkSecurityGroup_bastion.outputs.id
          }
          serviceEndpoints: []
          delegations: []
          privateEndpointNetworkPolicies: 'Enabled'
          privateLinkServiceNetworkPolicies: 'Enabled'
        }
        type: 'Microsoft.Network/virtualNetworks/subnets'
      }
    ]
  }
  dependsOn: [ resourceGroup ]
}

module keyVault_InfOps '../Modules/Security/KeyVault/vault.bicep' = {
  name: '${deployment().name}-kvinfDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-kv-infops'
    kvAdminGrpObjId: subscriptionkvAdminGroup
    kvReaderGrpObjId: subscriptionVKvReaderGroup
  }
  dependsOn: [ resourceGroup ]
}

module keyVault_AppOps '../Modules/Security/KeyVault/vault.bicep' = {
  name: '${deployment().name}-kvappDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-kv-appops'
    kvAdminGrpObjId: subscriptionkvAdminGroup
    kvReaderGrpObjId: subscriptionVKvReaderGroup
  }
  dependsOn: [ resourceGroup ]
}

module storageAccount_main '../Modules/Storage/StorageAccount/account.bicep' = {
  name: '${deployment().name}-storageMainDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${application}${env}mainst'
    allowBlobPublicAccess: false
    malwareScanningEnabled: true
    minimumTlsVersion: 'TLS1_2'
    allowedIPaddresses: allowedStorageIps
  }
  dependsOn: [ virtualNetwork ]
}

module storageAccount_diag '../Modules/Storage/StorageAccount/account.bicep' = {
  name: '${deployment().name}-storageDiagDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${application}${env}diagst'
    allowBlobPublicAccess: false
    minimumTlsVersion: 'TLS1_2'
    allowedIPaddresses: allowedStorageIps
  }
  dependsOn: [ virtualNetwork ]
}

module logAnalytics '../Modules/Insights/workspace.bicep' = {
  name: '${deployment().name}-omsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-log'
  }
  dependsOn: [ resourceGroup ]
}

module automationAccount '../Modules/Automation/account.bicep' = {
  name: '${deployment().name}-aaDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-aa'
  }
  dependsOn: [ resourceGroup ]
}

module publicIP_bastion '../Modules/Network/publicIp.bicep' = {
  name: '${deployment().name}-pubIpBastionDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-bas-pip'
    region: region
    zones: []
  }
  dependsOn: [ resourceGroup ]
}

module bastionHost '../Modules/Network/bastion.bicep' = {
  name: '${deployment().name}-bastionDeploy'
  scope: az.resourceGroup(rgName)
  params: {  
     bastionHostName: '${resourceSuffix}-bas'
     sku: 'Standard'
     region: region
     pubIpName: publicIP_bastion.outputs.name
     vNetName: virtualNetwork.outputs.name
   }
   dependsOn: [ virtualNetwork ]
}

module cognitiveSearch '../Modules/Search/search.bicep' = {
  name: '${deployment().name}-cogSearchDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-srch'
    region: region
  }
  dependsOn: [ resourceGroup ]
}

module adminVM '../Modules/Compute/VirtualMachines/windows.bicep' = {
  name: '${deployment().name}-admimVmDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    enableAcceleratedNetworking: false
    computerName: '${resourceSuffix}-vm'
    diagStorageAccountName: storageAccount_diag.outputs.name
    name: '${resourceSuffix}-vm'
    sku: '2016-Datacenter'
    subNetName: 'ops'
    vmPassword: 'P11iIyy&0o2VnIFB'
    vmUsername: 'investc_admin'
    vNetName: virtualNetwork.outputs.name
  }
}

module networkSecurityGroup_ops '../Modules/Network/nsg.bicep' = {
  name: '${deployment().name}-nsgOpsDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-ops-nsg'
  }
  dependsOn: [ resourceGroup ]
}

module networkSecurityGroup_ilbase '../Modules/Network/nsg.bicep' = {
  name: '${deployment().name}-nsgIlbaseDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-ilbase-nsg'
  }
  dependsOn: [ resourceGroup ]
}

module networkSecurityGroup_agw '../Modules/Network/nsg.bicep' = {
  name: '${deployment().name}-nsgAgwDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-agw-nsg'
  }
  dependsOn: [ resourceGroup ]
}

module networkSecurityGroup_sd '../Modules/Network/nsg.bicep' = {
  name: '${deployment().name}-nsgSdDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-sd-nsg'
  }
  dependsOn: [ resourceGroup ]
}

module networkSecurityGroup_bastion '../Modules/Network/nsg.bicep' = {
  name: '${deployment().name}-nsgBastionDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    name: '${resourceSuffix}-bastion-nsg'
    securityRules: [
       {
        name: 'Outbound-HTTPS'
        properties: {
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureCloud'
          access: 'Allow'
          priority: 150
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
         }
       }
       {
        name: 'Outbound-RDP'
        properties: {
          protocol: 'TCP'
          sourcePortRange: '*'
          destinationPortRange: '3389'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 140
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
       }
       {
        name: 'Inbound-GatewayManager'
        properties: {
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'GatewayManager'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 100
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
       }
      }
      {
        name: 'Inbound-AzureCloud'
        properties: {
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'AzureCloud'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 110
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'Internet-Bastion'
        properties: {
          description: 'Allows Internet Access to Azure Bastion Host'
          protocol: 'TCP'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: 'Internet'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 120
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'Outbound-SSH'
        properties: {
          protocol: 'TCP'
          sourcePortRange: '*'
          destinationPortRange: '22'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 130
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
    ]
  }
  dependsOn: [ resourceGroup ]
}

output opsKeyVaultUrl string = keyVault_InfOps.outputs.url
output vnetId string = virtualNetwork.outputs.id
output vnetName string = virtualNetwork.outputs.name
output opSubnetId string = virtualNetwork.outputs.subnets[0].id



     