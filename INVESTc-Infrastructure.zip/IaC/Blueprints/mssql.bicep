targetScope = 'subscription'

@description('The application being deployed. Allowed options are investc or hrg.')
@allowed([
  'investc'
  'hrg'
])
param application string

@description('The azure subscription/environment that the resource will be deployed to. Param is asking for the sub acronym not the full name.')
@allowed([
  'dev'
  'stg'
  'tst'
  'prd'
  'qa'
  'dsr'
])
param env string

@description('The name of the resource group to deploy the app resources in.')
param rgName string

@description('The region that the resource will be deployed to. Default is eastus; westus is only used for the disaster recovery environment.')
@allowed([
  'eastus'
  'westus'
])
param region string = 'eastus'

var resourceSuffix = '${application}-${env}'

module resourceGroup '../Modules/Management/resourcegroup.bicep' = {
  name: '${deployment().name}-rgDeploy'
  params: {
    application: application
    name: rgName
    region: region
  }
}

module sqlServer '../Modules/Database/SQL/server.bicep' = {
  name: '${deployment().name}-sqlServerDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    region: region
    adminLogin: 'investcadmin'
    adminPassword: ''
    sqlServerName: '${resourceSuffix}-sql'
  }
  dependsOn: [ resourceGroup ]
}

module database_investc '../Modules/Database/SQL/database.bicep' = {
  name: '${deployment().name}-investcdatabaseDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    databaseName: '${application}-sqldb'
    sqlServerName: sqlServer.name
  }
  dependsOn: [ resourceGroup ]
}

module database_servicedesk '../Modules/Database/SQL/database.bicep' = {
  name: '${deployment().name}-servicedeskdatabaseDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    databaseName: 'servicedesk-sqldb'
    sqlServerName: sqlServer.name
  }
  dependsOn: [ resourceGroup ]
}

module database_confluence '../Modules/Database/SQL/database.bicep' = {
  name: '${deployment().name}-confluencedatabaseDeploy'
  scope: az.resourceGroup(rgName)
  params: {
    databaseName: 'confluence-sqldb'
    sqlServerName: sqlServer.name
  }
  dependsOn: [ resourceGroup ]
}

