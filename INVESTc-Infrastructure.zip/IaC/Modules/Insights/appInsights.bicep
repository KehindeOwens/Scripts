targetScope = 'resourceGroup'

@description('The workspace data retention in days. Allowed values are per pricing plan. See pricing tiers documentation for details. Defaults to 360.')
param dataRetentioninDays int = 365

@allowed([
  'ApplicationInsights'
  'ApplicationInsightsWithDiagnosticSettings'
  'LogAnalytics' 
])
@description('Indicates the flow of the ingestion. Defaults to ApplicationInsights.')
param ingestionMode string = 'ApplicationInsights'

@description('The name of the App Insights resource')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@allowed([
  'Disabled'
  'Enabled'
])
@description('The network access type for accessing Application Insights query. Defaults to Enabled.')
param publicNetworkAccessForQuery string = 'Enabled'

@allowed([
  'Disabled'
  'Enabled' 
])
@description('The network access type for accessing Application Insights ingestion. Defaults to Enabled.')
param publicNetworkAccessForIngestion string = 'Enabled'

resource appInsights 'microsoft.insights/components@2020-02-02' = {
  name: name
  location: region
  kind: 'Web'
  properties: {
    Application_Type: 'Web'
    RetentionInDays: dataRetentioninDays
    IngestionMode: ingestionMode
    publicNetworkAccessForIngestion: publicNetworkAccessForIngestion
    publicNetworkAccessForQuery: publicNetworkAccessForQuery
  }
}

output name string = appInsights.name
output id string = appInsights.id
output connection_string string = appInsights.properties.ConnectionString
output instrumentation_key string = appInsights.properties.InstrumentationKey
