targetScope = 'resourceGroup'

@description('The workspace data retention in days. Allowed values are per pricing plan. See pricing tiers documentation for details. Defaults to 360.')
param dataRetentioninDays int = 360

@description('The name of the Log Analytics Workspace.')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@allowed([
  'Disabled'
  'Enabled'
])
@description('The network access type for accessing Log Analytics ingestion. Defaults to Enabled.')
param publicNetworkAccessForIngestion string = 'Enabled'

@allowed([
  'Disabled'
  'Enabled'
])
@description('The network access type for accessing Log Analytics query. Defaults to Enabled.')
param publicNetworkAccessForQuery string = 'Enabled'

@allowed([
  'CapacityReservation'
  'Free'
  'LACluster'
  'PerGB2018'
  'PerNode' 
  'Premium' 
  'Standalone' 
  'Standard'
])
@description('SKU type of the log anaylytics workspace. Defaults to PerGB2018.')
param skuType string = 'PerGB2018'

resource workSpace 'microsoft.operationalinsights/workspaces@2021-12-01-preview' = {
  name: name
  location: region
  properties: {
    sku: {
      name: skuType
    }
    retentionInDays: dataRetentioninDays
    features: {}
    workspaceCapping: {
      dailyQuotaGb: -1
    }
    publicNetworkAccessForIngestion: publicNetworkAccessForIngestion
    publicNetworkAccessForQuery: publicNetworkAccessForQuery
  }
}

output name string = workSpace.name
output id string = workSpace.id
