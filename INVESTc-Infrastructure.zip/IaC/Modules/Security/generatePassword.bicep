@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('Gets or sets how the deployment script should be forced to execute even if the script resource has not changed. Can be current time stamp or a GUID.')
param utcValue string

resource runPowerShellInlineWithOutput 'Microsoft.Resources/deploymentScripts@2020-10-01' = {
  name: 'runPowerShellInlineWithOutput'
  location: region
  kind: 'AzurePowerShell'
  properties: {
    forceUpdateTag: utcValue
    azPowerShellVersion: '6.4'
    scriptContent: '''
    $charlist = [char]94..[char]126 + [char]65..[char]90 + [char]47..[char]57
    $PasswordProfile = ($charlist | Get-Random -count 66) -join ''
    Write-Output $PasswordProfile
    $DeploymentScriptOutputs = @{}
    $DeploymentScriptOutputs["text"] = $PasswordProfile
    '''
    arguments: '-name'
    timeout: 'PT1H'
    retentionInterval: 'PT1H'
  }
}

output result string = runPowerShellInlineWithOutput.properties.outputs.text
