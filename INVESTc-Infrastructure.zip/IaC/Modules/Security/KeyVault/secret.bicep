@description('The name of the Key Vault that this access policy will be applied to.')
param kvName string

@description('The name of the Key Vault Secret.')
param secretName string

@description('The value of the secret. NOTE: value will never be returned from the service, as APIs using this model are is intended for internal use in ARM deployments. Users should use the data-plane REST service for interaction with vault secrets.')
@secure()
param secretValue string

resource keyVault 'Microsoft.KeyVault/vaults@2019-09-01' existing = {
  name: kvName
}

resource secret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: keyVault
  name: secretName
  properties: {
    value: secretValue
  }
}

output name string = secret.name
output id string = secret.id
