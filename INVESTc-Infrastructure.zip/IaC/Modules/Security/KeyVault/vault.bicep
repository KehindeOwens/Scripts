targetScope = 'resourceGroup'

@description('The Object ID of the Key Vault Reader AAD Group for this environment')
param kvAdminGrpObjId string

@description('The Object ID of the Key Vault Reader AAD Group for this environment')
param kvReaderGrpObjId string

@description('The name of the Key Vault')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@allowed([
  'premium'
  'standard'
])
@description('SKU name to specify whether the key vault is a standard vault or a premium vault. Defaults to standard.')
param skuType string = 'standard'

@allowed([
  'Disabled'
  'Enabled'
])
@description('Property to specify whether the vault will accept traffic from public internet. If set to disabled all traffic except private endpoint traffic and that that originates from trusted services will be blocked. This will override the set firewall rules, meaning that even if the firewall rules are present we will not honor the rules. Defaults to Enabled.')
param publicNetworkAccess string = 'Enabled'

resource keyVault 'Microsoft.KeyVault/vaults@2023-02-01' = {
  name: name
  location: region
  properties: {
    sku: {
      family: 'A'
      name: skuType
    }
    tenantId: subscription().tenantId
    accessPolicies: [
      {
        tenantId: subscription().tenantId
        objectId: '02fb973f-b248-43c4-8f25-68ed296e5f4b' // Kehinde L Ford
        permissions: {
          keys: [
            'Backup'
            'Create'
            'Delete'
            'Decrypt'
            'Encrypt'
            'Get'
            'Import'
            'List'
            'Purge'
            'Recover'
            'Restore'
            'Sign'
            'UnwrapKey'
            'Update'
            'Verify'
            'WrapKey'
          ]
          secrets: [
            'Backup'
            'Delete'
            'Get'
            'List'
            'Purge'
            'Recover'
            'Restore'
            'Set'
          ]
          certificates: [
            'Get'
            'List'
            'Update'
            'Create'
            'Import'
            'Delete'
            'Recover'
            'ManageContacts'
            'ManageIssuers'
            'GetIssuers'
            'ListIssuers'
            'SetIssuers'
            'DeleteIssuers'
            'Purge'
          ]
          storage: [
            'get'
            'list'
            'delete'
            'set'
            'update'
            'regeneratekey'
            'getsas'
            'listsas'
            'deletesas'
            'setsas'
            'recover'
            'backup'
            'restore'
            'purge'
          ]
        }
      }
      {
        tenantId: subscription().tenantId
        objectId: kvAdminGrpObjId     // Key Vault Admin AAD Group
        permissions: {
          keys: [
            'Backup'
            'Create'
            'Delete'
            'Decrypt'
            'Encrypt'
            'Get'
            'Import'
            'List'
            'Purge'
            'Recover'
            'Restore'
            'Sign'
            'UnwrapKey'
            'Update'
            'Verify'
            'WrapKey'
          ]
          secrets: [
            'Backup'
            'Delete'
            'Get'
            'List'
            'Purge'
            'Recover'
            'Restore'
            'Set'
          ]
          certificates: [
            'Get'
            'List'
            'Update'
            'Create'
            'Import'
            'Delete'
            'Recover'
            'ManageContacts'
            'ManageIssuers'
            'GetIssuers'
            'ListIssuers'
            'SetIssuers'
            'DeleteIssuers'
            'Purge'
          ]
          storage: [
            'get'
            'list'
            'delete'
            'set'
            'update'
            'regeneratekey'
            'getsas'
            'listsas'
            'deletesas'
            'setsas'
            'recover'
            'backup'
            'restore'
            'purge'
          ]
        }
      }
      {
        tenantId: subscription().tenantId
        objectId: kvReaderGrpObjId  // Key Vault Reader AAD Group
        permissions: {
          keys: [
            'Get'
            'List'
          ]
          secrets: [
            'Get'
            'List'
          ]
          certificates: [
            'Get'
            'List'
            'Update'
            'GetIssuers'
            'ListIssuers'
          ]
          storage: [
            'get'
            'list'
            'getsas'
            'listsas'
          ]
        }
      }
    ]
    enabledForDeployment: true
    enabledForDiskEncryption: true
    enabledForTemplateDeployment: true
    softDeleteRetentionInDays: 90
    vaultUri: 'https://${name}.vault.azure.net/'
    publicNetworkAccess: publicNetworkAccess
  }
}

output name string = keyVault.name
output id string = keyVault.id
output url string = keyVault.properties.vaultUri
