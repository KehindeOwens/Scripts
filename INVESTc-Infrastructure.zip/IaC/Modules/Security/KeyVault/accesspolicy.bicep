targetScope = 'resourceGroup'

@description('The action that is being performed with this access policy. Default value is add.')
@allowed([
  'add'
  'remove'
  'replace'
])
param action string = 'add'

@description('The perms to be assigned for key vault certificates. Defaults to empty array.')
param certPermissions array = []

@description('The perms to be assigned for key vault keys. Defaults to empty array.')
param keyPermissions array = []

@description('The object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault. The object ID must be unique for the list of access policies.')
param identityObjId string

@description('The perms to be assigned for key vault secrets. Defaults to empty array.')
param secretPermissions array = []

@description('The perms to be assigned for key vault storage. Defaults to empty array.')
param storagePermissions array = []

@description('The name of the Key Vault that this access policy will be applied to.')
param kvName string

resource keyVault 'Microsoft.KeyVault/vaults@2019-09-01' existing = {
  name: kvName
}

 resource accessPolicy 'Microsoft.KeyVault/vaults/accessPolicies@2022-07-01' = {
  name: action
  parent: keyVault
  properties: {
    accessPolicies: [
      {
        objectId: identityObjId
        permissions: {
          certificates: certPermissions
          keys:  keyPermissions
          secrets: secretPermissions
          storage: storagePermissions
        }
        tenantId: subscription().tenantId
      }
    ]
  }
}
