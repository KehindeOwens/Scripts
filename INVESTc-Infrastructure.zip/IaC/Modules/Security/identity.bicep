targetScope = 'resourceGroup'

@description('The name of the Managed Identity.')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

resource userAssignedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: name
  location: region
}

output name string = userAssignedIdentity.name
output id string = userAssignedIdentity.id
output objectid string = userAssignedIdentity.properties.principalId
