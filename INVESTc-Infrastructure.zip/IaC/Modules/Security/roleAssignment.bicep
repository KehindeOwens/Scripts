targetScope = 'resourceGroup'

@description('The role definition Id. This is the ending Guid of the full resource ID. ex. b7e6dc6d-f1e8-4753-8033-0f276bb0955b is the id of storage blob data owner.')
param roleDefinitionId string

@allowed([
  'Device'
  'ForeignGroup'
  'Group'
  'ServicePrincipal'
  'User'
])
@description('The principal type of the assigned principal ID. Defaults to ServicePrincipal.')
param principalType string = 'ServicePrincipal'

@description('The name of the managed identity to associate the role to.')
param umiName string


resource userAssignedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: umiName
}

@description('This is the built-in Contributor role. See https://docs.microsoft.com/azure/role-based-access-control/built-in-roles#contributor')
resource roleDefinition 'Microsoft.Authorization/roleDefinitions@2018-01-01-preview' existing = {
  scope: subscription()
  name: roleDefinitionId
}

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(userAssignedIdentity.id, roleDefinition.id)
  properties: {
    principalId: userAssignedIdentity.properties.principalId
    principalType: principalType
    roleDefinitionId: roleDefinition.id
  }
}
