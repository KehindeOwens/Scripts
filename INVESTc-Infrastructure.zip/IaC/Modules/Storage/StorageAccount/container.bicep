@description('The object level immutability property of the container. The property is immutable and can only be set to true at the container creation time. Existing containers must undergo a migration process. Default value is false.')
param immutableStorageWithVersioningEnabled bool = false

@description('The name of the container to provision in the storage account.')
param name string

@allowed([
  'Blob'
  'Container'
  'None'
])
@description('Specifies whether data in the container may be accessed publicly and the level of access. Default to None')
param publicAccess string = 'None'

@description('The name of the storage account that the container should be provisioned in.')
param storageAccountName string

resource storageAccount 'Microsoft.Storage/storageAccounts@2022-09-01' existing = {
  name: storageAccountName
}

resource storageAccount_BlobService 'Microsoft.Storage/storageAccounts/blobServices@2022-09-01' existing = {
  parent: storageAccount
  name: 'default'
}

resource storageAccount_Container 'Microsoft.Storage/storageAccounts/blobServices/containers@2022-09-01' = {
  parent: storageAccount_BlobService
  name: name
  properties: {
    immutableStorageWithVersioning: {
      enabled: immutableStorageWithVersioningEnabled
    }
    defaultEncryptionScope: '$account-encryption-key'
    denyEncryptionScopeOverride: false
    publicAccess: publicAccess
  }
}
