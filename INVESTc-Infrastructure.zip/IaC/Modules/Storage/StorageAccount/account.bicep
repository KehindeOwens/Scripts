@allowed([
  'Cool'
  'Hot'
  'Premium'
])
@description('Required for storage accounts where kind = BlobStorage. The access tier is used for billing. The Premium access tier is the default value for premium block blobs storage account type and it cannot be changed for the premium block blobs storage account type.')
param accessTier string = 'Hot'

@description('Allow or disallow public access to all blobs or containers in the storage account. The default interpretation is true for this property.')
param allowBlobPublicAccess bool = true

@description('Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). The default value is false.')
param allowSharedKeyAccess bool = false

@description('Indicates the virtual network(s) and nested subnets that are allowed access to the storage account. Defaults to an empty array.')
param allowedSubnetIds array = []

@description('Indicates the individual IPs or CIDRs that are allowed access to the storage account. Default to an empty array.')
param allowedIPaddresses array = []

@description('Indicates the number of days that the deleted item should be retained. The minimum specified value can be 1 and the maximum value can be 365. Default value is 14.')
param blobRetentionDays int = 14

@allowed([
  'TLS1_0'
  'TLS1_1'
  'TLS1_2'
])
@description('Set the minimum TLS version to be permitted on requests to storage. The default interpretation is TLS 1.0 for this property.')
param minimumTlsVersion string = 'TLS1_2'

@allowed([
  'Premium_LRS'
  'Premium_ZRS'
  'Standard_GRS'
  'Standard_GZRS'
  'Standard_LRS'
  'Standard_RAGRS'
  'Standard_RAGZRS'
  'Standard_ZRS'
])
@description('Sku Type of the storage account. Defaults to Standard_LRS.')
param skuType string = 'Standard_LRS'

@allowed([
  'BlobStorage'
  'BlockBlobStorage'
  'FileStorage'
  'Storage'
  'StorageV2'
])
@description('Indicates the type of storage account. Defaults to StorageV2.')
param storageType string = 'StorageV2'

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('The name of the storage account.')
param name string

@description('Indicates whether On Upload malware scanning should be enabled. Default value is false')
param malwareScanningEnabled bool = false

var allowedSubnets = [ for subnetId in allowedSubnetIds: {
  action: 'Allow'
  id: subnetId
}]
var publicNetworkAccess = (empty(allowedSubnets))? 'Disabled' : 'Enabled'

var allowedIps = [ for ip in allowedIPaddresses: {
  action: 'Allow'
  value: ip.value
}]

resource storageAccount 'Microsoft.Storage/storageAccounts@2022-09-01' = {
  name: name
  location: region
  sku: {
    name: skuType
  }
  kind: storageType
  properties: {
    allowBlobPublicAccess: allowBlobPublicAccess
    allowSharedKeyAccess: allowSharedKeyAccess
    allowedCopyScope: 'AAD'
    allowCrossTenantReplication: false
    minimumTlsVersion: minimumTlsVersion
    publicNetworkAccess: publicNetworkAccess
    networkAcls: {
      bypass: 'AzureServices'
      virtualNetworkRules: allowedSubnets
      ipRules: allowedIps
      defaultAction: 'Deny'
    }
    supportsHttpsTrafficOnly: true
    encryption: {
      services: {
        file: {
          keyType: 'Account'
          enabled: true
        }
        blob: {
          keyType: 'Account'
          enabled: true
        }
      }
      keySource: 'Microsoft.Storage'
    }
    accessTier: accessTier
  }
}

resource storageAccount_blobService 'Microsoft.Storage/storageAccounts/blobServices@2022-09-01' = {
  parent: storageAccount
  name: 'default'
  properties: {
    containerDeleteRetentionPolicy: {
      enabled: true
      days: blobRetentionDays
    }
    cors: {
      corsRules: []
    }
    deleteRetentionPolicy: {
      allowPermanentDelete: false
      enabled: false
    }
    isVersioningEnabled: true
  }
}

resource defenderForStorageSettings 'Microsoft.Security/DefenderForStorageSettings@2022-12-01-preview' = {
  name: 'current'
  scope: storageAccount
  properties: {
    isEnabled: true
    malwareScanning: {
      onUpload: {
        isEnabled: malwareScanningEnabled
        capGBPerMonth: 5000
      }
    }
    sensitiveDataDiscovery: {
    isEnabled: true
    }
    overrideSubscriptionLevelSettings: true
  }
}

output name string = storageAccount.name
output id string = storageAccount.id
output uri string = storageAccount.properties.primaryEndpoints.web
