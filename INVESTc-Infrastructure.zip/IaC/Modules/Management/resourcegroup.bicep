targetScope = 'subscription'

@allowed([
  'investc'
  'hrg'
])
@description('The name of application the resource is being provisioned for.')
param application string

@description('The name of the resource group.')
param name string

@allowed([
  'eastus'
  'westus'
])
@description('The region that the resource will be deployed into.')
param region string

resource resourceGroup 'Microsoft.Resources/resourceGroups@2022-09-01' = {
  name: name
  location: region
  tags: {
    region: region
    application: application
    environment: subscription().displayName
  }
  properties: {}
}

output name string = resourceGroup.name
output id string = resourceGroup.id
