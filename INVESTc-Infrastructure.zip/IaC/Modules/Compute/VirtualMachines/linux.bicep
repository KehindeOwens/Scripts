targetScope = 'resourceGroup'

@description('Will the virtual machine shutdown on a nightly schedule. Defaults to true.')
param AutoShutDownEnabled bool = true

@description('Specifies the host OS name of the virtual machine. This name cannot be updated after the VM is created. Max-length (Windows): 15 characters. Max-length (Linux): 64 characters.')
param computerName string

@description('The name of the storage account to be used for diagnostics.')
param diagStorageAccountName string

@description('The name of the diagnostic storage account resource group.')
param diagStorageAccountRG string

@description('If the network interface is accelerated networking enabled. Default value is true.')
param enableAcceleratedNetworking bool = true

@description('Create Option for Data Disk. Defaults to Empty.')
@allowed([
  'Attach'
  'Empty'
  'FromImage'
])
param managedDiskCreateOption string = 'Empty'

@description('Specifies whether the data disk should be deleted or detached upon VM deletion. Possible values are: Delete. If this value is used, the data disk is deleted when VM is deleted. Detach. If this value is used, the data disk is retained after VM is deleted. The default value is set to Delete.')
@allowed([
  'Delete'
  'Detach'
])
param managedDiskDeleteOption string = 'Delete'

@description('Specifies the logical unit number of the data disk. This value is used to identify data disks within the VM and therefore must be unique for each data disk attached to a VM. Default value is 0')
param managedDiskLun int = 0

@description('Specifies the size of an empty data disk in gigabytes. This element can be used to overwrite the size of the disk in a virtual machine image. The property diskSizeGB is the number of bytes x 1024^3 for the disk and the value cannot be larger than 1023. The default value is set to 1023GB.')
param managedDiskSize int = 1023

@description('Specifies the storage account type for the managed disk. NOTE: UltraSSD_LRS can only be used with data disks, it cannot be used with OS Disk. Defaults to Standard_LRS')
@allowed([
  'PremiumV2_LRS'
  'Premium_LRS'
  'Premium_ZRS'
  'StandardSSD_LRS'
  'StandardSSD_ZRS'
  'Standard_LRS'
  'UltraSSD_LRS'
])
param managedDiskStorageAccountType string = 'Standard_LRS'

@description('Specifies how the virtual machine should be created. Possible values are: Attach. This value is used when you are using a specialized disk to create the virtual machine. FromImage. This value is used when you are using an image to create the virtual machine. If you are using a platform image, you should also use the imageReference element described above. If you are using a marketplace image, you should also use the plan element previously described. Defaults to FromImage')
@allowed([
  'Attach'
  'Empty'
  'FromImage'
])
param osDiskCreateOption string = 'FromImage'

@description('Specifies whether the os disk should be deleted or detached upon VM deletion. Possible values are: Delete. If this value is used, the data disk is deleted when VM is deleted. Detach. If this value is used, the data disk is retained after VM is deleted. The default value is set to Delete.')
@allowed([
  'Delete'
  'Detach'
])
param osDiskDeleteOption string = 'Delete'

@description('Name of the OS Disk, defaults to empty string(use default name).')
param osDiskName string = ''

@description('Specifies the size of an empty os disk in gigabytes. This element can be used to overwrite the size of the disk in a virtual machine image. The property diskSizeGB is the number of bytes x 1024^3 for the disk and the value cannot be larger than 1023. The default value is set to 1023GB.')
param osDiskSize int = 1023

@description('The time that the virtual machine will deallocate every day.')
param shutdownHour string = '19:00'

@description('Name of the Data Disk, defaults to empty string(use default name).')
param dataDiskName string = ''

@description('Specifies how the virtual machine should be created. Possible values are: Attach. This value is used when you are using a specialized disk to create the virtual machine. FromImage. This value is used when you are using an image to create the virtual machine. If you are using a platform image, you should also use the imageReference element described above. If you are using a marketplace image, you should also use the plan element previously described. Defaults to Standard_LRS')
@allowed([
  'PremiumV2_LRS'
  'Premium_LRS'
  'Premium_ZRS'
  'StandardSSD_LRS'
  'StandardSSD_ZRS'
  'Standard_LRS'
  'UltraSSD_LRS'
])
param osStorageAccountType string = 'Standard_LRS'

@description('SSH public key certificate used to authenticate with the VM through ssh. The key needs to be at least 2048-bit and in ssh-rsa format. For creating ssh keys, see [Create SSH keys on Linux and Mac for Linux VMs in Azure.')
param sshPublicKey string

@description('The sku type of the virtual machine. Defaults to Windows Server 2022-DataCenter')
@allowed([
  '87-gen2'
  '92-gen2'
])
param sku string

@allowed([
  'Basic_A0'
  'Basic_A1'
  'Basic_A2'
  'Basic_A3'
  'Basic_A4'
  'Standard_A0'
  'Standard_A1'
  'Standard_A10'
  'Standard_A11'
  'Standard_A1_v2'
  'Standard_A2'
  'Standard_A2_v2'
  'Standard_A2m_v2'
  'Standard_A3'
  'Standard_A4'
  'Standard_A4_v2'
  'Standard_A4m_v2'
  'Standard_A5'
  'Standard_A6'
  'Standard_A7'
  'Standard_A8'
  'Standard_A8_v2'
  'Standard_A8m_v2'
  'Standard_A9'
  'Standard_B1ms'
  'Standard_B1s'
  'Standard_B2ms'
  'Standard_B2s'
  'Standard_B4ms'
  'Standard_B8ms'
  'Standard_D1'
  'Standard_D11'
  'Standard_D11_v2'
  'Standard_D12'
  'Standard_D12_v2'
  'Standard_D13'
  'Standard_D13_v2'
  'Standard_D14'
  'Standard_D14_v2'
  'Standard_D15_v2'
  'Standard_D16_v3'
  'Standard_D16s_v3'
  'Standard_D1_v2'
  'Standard_D2'
  'Standard_D2_v2'
  'Standard_D2_v3'
  'Standard_D2s_v3'
  'Standard_D3'
  'Standard_D32_v3'
  'Standard_D32s_v3'
  'Standard_D3_v2'
  'Standard_D4'
  'Standard_D4_v2' 
  'Standard_D4_v3'
  'Standard_D4s_v3'
  'Standard_D5_v2'
  'Standard_D64_v3'
  'Standard_D64s_v3'
  'Standard_D8_v3'
  'Standard_D8s_v3'
  'Standard_DS1'
  'Standard_DS11'
  'Standard_DS11_v2'
  'Standard_DS12'
  'Standard_DS12_v2'
  'Standard_DS13'
  'Standard_DS13-2_v2'
  'Standard_DS13-4_v2'
  'Standard_DS13_v2'
  'Standard_DS14'
  'Standard_DS14-4_v2'
  'Standard_DS14-8_v2'
  'Standard_DS14_v2'
  'Standard_DS15_v2'
  'Standard_DS1_v2'
  'Standard_DS2'
  'Standard_DS2_v2'
  'Standard_DS3'
  'Standard_DS3_v2'
  'Standard_DS4'
  'Standard_DS4_v2'
  'Standard_DS5_v2'
  'Standard_E16_v3'
  'Standard_E16s_v3'
  'Standard_E2_v3'
  'Standard_E2s_v3'
  'Standard_E32-16_v3'
  'Standard_E32-8s_v3'
  'Standard_E32_v3'
  'Standard_E32s_v3'
  'Standard_E4_v3'
  'Standard_E4s_v3'
  'Standard_E64-16s_v3'
  'Standard_E64-32s_v3'
  'Standard_E64_v3'
  'Standard_E64s_v3'
  'Standard_E8_v3'
  'Standard_E8s_v3'
  'Standard_F1'
  'Standard_F16'
  'Standard_F16s'
  'Standard_F16s_v2'
  'Standard_F1s'
  'Standard_F2'
  'Standard_F2s'
  'Standard_F2s_v2'
  'Standard_F32s_v2'
  'Standard_F4'
  'Standard_F4s'
  'Standard_F4s_v2'
  'Standard_F64s_v2'
  'Standard_F72s_v2'
  'Standard_F8'
  'Standard_F8s'
  'Standard_F8s_v2'
  'Standard_G1'
  'Standard_G2'
  'Standard_G3'
  'Standard_G4'
  'Standard_G5'
  'Standard_GS1'
  'Standard_GS2'
  'Standard_GS3'
  'Standard_GS4'
  'Standard_GS4-4'
  'Standard_GS4-8'
  'Standard_GS5'
  'Standard_GS5-16'
  'Standard_GS5-8'
  'Standard_H16'
  'Standard_H16m'
  'Standard_H16mr'
  'Standard_H16r'
  'Standard_H8'
  'Standard_H8m'
  'Standard_L16s'
  'Standard_L32s'
  'Standard_L4s'
  'Standard_L8s'
  'Standard_M128-32ms'
  'Standard_M128-64ms'
  'Standard_M128ms'
  'Standard_M128s'
  'Standard_M64-16ms'
  'Standard_M64-32ms'
  'Standard_M64ms'
  'Standard_M64s'
  'Standard_NC12'
  'Standard_NC12s_v2'
  'Standard_NC12s_v3'
  'Standard_NC24'
  'Standard_NC24r'
  'Standard_NC24rs_v2'
  'Standard_NC24rs_v3'
  'Standard_NC24s_v2'
  'Standard_NC24s_v3'
  'Standard_NC6'
  'Standard_NC6s_v2'
  'Standard_NC6s_v3'
  'Standard_ND12s'
  'Standard_ND24rs'
  'Standard_ND24s'
  'Standard_ND6s'
  'Standard_NV12'
  'Standard_NV24'
  'Standard_NV6' 
])
@description('Specifies the size of the virtual machine. Defaults to Standard_B4ms.')
param size string = 'Standard_B4ms'

@description('The name of the subnet to associate the server to.')
param subNetName string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('The name of the virtual machine.')
param name string

@description('Whether boot diagnostics should be enabled on the Virtual Machine. Default value is true.')
param vmDiagnosticsEnabled bool = true

@description('The name of the virtual machine admin user.')
param vmUsername string

@description('The name of the virtual network to associate the server to.')
param vNetName string

@description('The Resource Group that the Virtual Network Resides in.')
param vNetRG string

// Create OS Disk, named other than default if the name was passed in
var osDisk = {
  osType: 'Linux'
  createOption: osDiskCreateOption
  managedDisk: {
    storageAccountType: osStorageAccountType
  }
  deleteOption: osDiskDeleteOption
  diskSizeGB: osDiskSize
}
var namedOsDisk = (empty(osDiskName))? osDisk : union({name: osDiskName}, osDisk)

// Create Data Disk, named other than default if the name was passed in
var dataDisk = {
  createOption: managedDiskCreateOption
  deleteOption: managedDiskDeleteOption
  diskSizeGB: managedDiskSize
  lun: managedDiskLun
  managedDisk: {
    storageAccountType: managedDiskStorageAccountType
  }
}
var namedDataDisk = (empty(dataDiskName))? dataDisk : union({name: dataDiskName}, dataDisk)

resource storageAccount 'Microsoft.Storage/storageAccounts@2022-09-01' existing = { 
  scope: resourceGroup(diagStorageAccountRG)
  name: diagStorageAccountName
}

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2021-08-01' existing = {
  scope: resourceGroup(vNetRG)
  name: vNetName
}

resource subnet 'Microsoft.Network/virtualNetworks/subnets@2021-08-01' existing = {
  parent: virtualNetwork
  name: subNetName
}

resource networkInterface 'Microsoft.Network/networkInterfaces@2021-03-01' = {
  name: '${name}-nic'
  location: region
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          subnet: {
            id: subnet.id
          }
          privateIPAllocationMethod: 'Dynamic'
          privateIPAddressVersion: 'IPv4'
        }
      }
    ]
    enableAcceleratedNetworking: enableAcceleratedNetworking
  }
}

resource virtualMachine 'Microsoft.Compute/virtualMachines@2023-03-01' = {
  name: name
  location: region
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    hardwareProfile: {
      vmSize: size
    }
    storageProfile: {
      osDisk: namedOsDisk
      imageReference: {
        publisher: 'RedHat'
        offer: 'RHEL'
        sku: sku
        version: 'latest'
      }
      dataDisks: [ namedDataDisk ]
      diskControllerType: 'SCSI'
    }
    osProfile: {
      computerName: computerName
      adminUsername: vmUsername
      linuxConfiguration: {
        disablePasswordAuthentication: true
        ssh: {
          publicKeys: [
            {
              path: '/home/${vmUsername}/.ssh/authorized_keys'
              keyData: sshPublicKey
            }
          ]
        }
        provisionVMAgent: true
        patchSettings: {
          patchMode: 'ImageDefault'
          assessmentMode: 'ImageDefault'
        }
        enableVMAgentPlatformUpdates: false
      }
      secrets: []
      allowExtensionOperations: true
      requireGuestProvisionSignal: true
    }
    securityProfile: {
      uefiSettings: {
        secureBootEnabled: true
        vTpmEnabled: true
      }
      securityType: 'TrustedLaunch'
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: networkInterface.id
          properties: {
            deleteOption: 'Delete'
          }
        }
      ]
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: vmDiagnosticsEnabled
        storageUri: 'https://${storageAccount.name}.blob.core.windows.net/'
      }
    }
  }
}

resource enablevmaccess 'Microsoft.Compute/virtualMachines/extensions@2023-03-01' = {
  parent: virtualMachine
  name: 'enablevmAccess'
  location: region
  properties: {
    autoUpgradeMinorVersion: true
    publisher: 'Microsoft.OSTCExtensions'
    type: 'VMAccessForLinux'
    typeHandlerVersion: '1.5'
    settings: {}
    protectedSettings: {}
  }
}

resource enablevmshutdown 'Microsoft.DevTestLab/schedules@2018-09-15' = if (AutoShutDownEnabled == true) {
  name: 'shutdown-computevm-${name}'
  location: region
  properties: {
    status: 'Enabled'
    taskType: 'ComputeVmShutdownTask'
    dailyRecurrence: { 
      time: shutdownHour
    }
    notificationSettings: {
       status: 'Disabled'
    }
    targetResourceId: virtualMachine.id
    timeZoneId: 'Eastern Standard Time'
  }
}

output name string = virtualMachine.name
output id string = virtualMachine.id
