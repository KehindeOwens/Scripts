targetScope = 'resourceGroup'

@description('FeatureFlags is the supported features of Azure SignalR service. Default is ServiceMode.')
@allowed([
  'EnableConnectivityLogs' 
  'EnableLiveTrace' 
  'EnableMessagingLogs' 
  'ServiceMode'
])
param featureFlags string = 'ServiceMode'

@description('The name of the SignalR resource')
param name string 

@description('Resource location')
param region string = resourceGroup().location

@description('Enable or disable public network access. Default to "Enabled". When Enabled, network ACLs still apply. When Disabled, public network access is always disabled no matter what you set in network ACLs.')
@allowed([
  'disabled'
  'enabled'
])
param publicNetworkAccess string = 'enabled'

@description('The sku type of the SignalR resource. Default value is Free_F1.')
@allowed([
  'Standard_S1'
  'Free_F1'
  'Premium_P1'
])
param sku string = 'Free_F1'

resource signalR 'Microsoft.SignalRService/SignalR@2023-08-01-preview' = {
  name: name
  location: region
  sku: {
    name: sku
    capacity: 1
  }
  kind: 'SignalR'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    tls: {
      clientCertEnabled: false
    }
    features: [
      {
        flag: featureFlags
        value: 'Serverless'
        properties: {}
      }
    ]
    cors: {
      allowedOrigins: [
        '*'
      ]
    }
    serverless: {
      connectionTimeoutInSeconds: 30
    }
    upstream: {}
    networkACLs: {
      defaultAction: 'Deny'
      publicNetwork: {
        allow: [
          'ServerConnection'
          'ClientConnection'
          'RESTAPI'
          'Trace'
        ]
      }
      privateEndpoints: []
      ipRules: []
    }
    publicNetworkAccess: publicNetworkAccess
    disableLocalAuth: false
    disableAadAuth: false
    regionEndpointEnabled: 'Enabled'
    resourceStopped: 'false'
  }
}

output name string = signalR.name
output id string = signalR.id
