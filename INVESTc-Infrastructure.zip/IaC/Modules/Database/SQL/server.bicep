targetScope = 'resourceGroup'

@description('The subscription the resource will be deployed into.')
param env string 

@description('The name of the Sql Server')
param sqlServerName string 

@description('Resource location')
param region string = resourceGroup().location

@description('Administrator username for the server. Once created it cannot be changed.')
@secure()
param adminLogin string

@description('The administrator login password (required for server creation).')
@secure()
param adminPassword string

@description('The Object ID of the Microsoft Entra Group to make the SQL Server Admin.')
param adminGroupOID string 

@description('Is Azure Active Directory only Authentication enabled on the SQL Server. Default value is false.')
param azureADOnlyAuthentication bool = false

@description('The version of the server.')
param version string = '12.0'

@description('Minimal TLS version. Allowed values')
@allowed([
  'None'
  '1.0'
  '1.1'
  '1.2'
])
param minimalTlsVersion string = '1.0'

@description('Whether or not public endpoint access is allowed for this server. Default value is Enabled.')
@allowed([
  'Enabled'
  'Disabled'
  'SecuredByPerimeter'
])
param publicNetworkAccess string = 'Enabled'

@description('Whether or not to restrict outbound network access for this server. Value is optional but if passed in, must be from allowed values')
@allowed([
  'Enabled' 
  'Disabled'
])
param outBoundAccess string = 'Disabled'

resource sqlServer 'Microsoft.Sql/servers@2022-08-01-preview' = {
  name: sqlServerName
  location: region
  properties: {
    administratorLogin: adminLogin
    administratorLoginPassword: adminPassword
    version: version
    minimalTlsVersion: minimalTlsVersion
    publicNetworkAccess: publicNetworkAccess
    restrictOutboundNetworkAccess: outBoundAccess
    administrators: {
      administratorType: 'ActiveDirectory'
      azureADOnlyAuthentication: azureADOnlyAuthentication
      login: 'investc-${env}-sqladmin'
      principalType: 'Group'
      sid: adminGroupOID
      tenantId: subscription().subscriptionId
    }
  }
}

output name string = sqlServer.name
output id string = sqlServer.id


