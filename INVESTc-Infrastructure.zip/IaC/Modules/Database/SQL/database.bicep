targetScope = 'resourceGroup'

@description('The name of the Sql Server')
param sqlServerName string 

@description('Resource location')
param region string = resourceGroup().location

@description('Name of the sql server/database resource. string (required) Character limit: 1-128. Valid characters: Cannot use: <>*%&:? or control characters. Cannot end with period or space.')
param databaseName string

@description('''The name of the SKU, typically, a letter + Number code, e.g. P3. The list of SKUs may vary by region and support offer. 
- To determine the SKUs (including the SKU name, tier/edition, family, and capacity) that are available to your subscription in an Azure region, use the Capabilities_ListByLocation REST API or one of the following commands:
- Azure CLI:
az sql db list-editions -l {location} -o table
- Azure PowerShell:
Get-AzSqlServerServiceObjective -Location {location}''')
param sqlDbSKU string = 'Basic'

@description('Capacity of the particular sql database SKU.')
param sqlDBCapacity int = 5

@description('The tier or edition of the particular SKU, e.g. Basic, Premium.') 
@allowed([
  'Basic'
  'Premium'
])
param sqlDbTier string = 'Basic'

@description('The collation of the database.')
param dbCollation string = 'SQL_Latin1_General_CP1_CS_AS'

@description('The max size of the database expressed in bytes.')
param dbMaxbytes int = 2147483648

@allowed([
  'DATABASE_DEFAULT'
  'SQL_Latin1_General_CP1_CI_AS'
])
@description('Collation of the metadata catalog.')
param dbCatalogColl string = 'SQL_Latin1_General_CP1_CI_AS'

@allowed([
  'Geo' 
  'GeoZone' 
  'Local'
  'Zone'
])
@description('The storage account type to be used to store backups for this database.')
param reqBackupRedun string = 'Geo'

@allowed([
  '1' 
  '2'
  '3'
  'NoPreference'
])
@description('Specifies the availability zone the database is pinned to.')
param availabilityZone string = 'NoPreference'

resource sqlServer 'Microsoft.Sql/servers@2022-08-01-preview' existing = {
  name: sqlServerName
}

resource sqlServerDB 'Microsoft.Sql/servers/databases@2022-08-01-preview' = {
  parent: sqlServer
  name: databaseName
  location: region
  sku: {
    name: sqlDbSKU
    tier: sqlDbTier
    capacity: sqlDBCapacity
  }
  properties: {
    collation: dbCollation
    maxSizeBytes: dbMaxbytes
    catalogCollation: dbCatalogColl
    zoneRedundant: false
    readScale: 'Disabled'
    requestedBackupStorageRedundancy: reqBackupRedun
    isLedgerOn: false
    availabilityZone: availabilityZone
  }
  
}

output name string = sqlServerDB.name
output id string = sqlServerDB.id


