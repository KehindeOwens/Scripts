targetScope = 'resourceGroup'

@description('The CIDR prefix of the virtual network.')
param addressPrefix string

@description('The CIDR suffix of the virtual network. Defaults to /24.')
param addressSuffix string = '24'

@description('A list of subnets in a Virtual Network. Defaults to an empty array.')
param subnets array = []

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('The name of the Virtual Network.')
param vNetName string

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2022-09-01' = {
  name: vNetName
  location: region
  properties: {
    addressSpace: {
      addressPrefixes: [
        '${addressPrefix}/${addressSuffix}'
      ]
    }
    subnets: subnets
    dhcpOptions: {
      dnsServers: []
    }
    virtualNetworkPeerings: []
    enableDdosProtection: false
  }
}

output name string = virtualNetwork.name
output id string = virtualNetwork.id
output subnets array = virtualNetwork.properties.subnets
output cidr object = virtualNetwork.properties.addressSpace
