 @description('The IP Cidr of the virtual network being peered to.')
param remoteVirtualNetworkCidr string[]

@description('The resource ID of the virtual network to peer to.')
param remoteVirtualNetworkId string

@description('The IP Cidr of the virtual network.')
param virtualNetworkCidr string[]

@description('The name of the virtual network peering.')
param vNetPeeringName string 

@description('The name of the Virtual Network.')
param vNetName string

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2022-09-01' existing = { 
  name: vNetName
}

resource vNetPeering 'Microsoft.Network/virtualNetworks/virtualNetworkPeerings@2022-01-01' = {
  name: vNetPeeringName
  parent: virtualNetwork
  properties: {
    allowForwardedTraffic: false
    allowGatewayTransit: false
    allowVirtualNetworkAccess: true
    doNotVerifyRemoteGateways: false
    remoteAddressSpace: {
      addressPrefixes: virtualNetworkCidr
    }
    remoteVirtualNetwork: {
      id: remoteVirtualNetworkId
    }
    remoteVirtualNetworkAddressSpace: {
      addressPrefixes: remoteVirtualNetworkCidr
    }
    useRemoteGateways: false
  }
}

