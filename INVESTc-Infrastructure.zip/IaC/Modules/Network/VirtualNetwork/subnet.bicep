@description('The CIDR prefix of the subnet.')
param addressPrefix string

@description('The CIDR suffix of the subnet. Defaults to /28.')
param addressSuffix string = '28'

@description('An array of references to the delegations on the subnet. Defaults to empty array.')
param delegations array = []

@description('An array of service endpoints. Defaults to empty array.')
param serviceEndpoints array = []

@description('The name of the subnet to create.')
param subNetName string 

@description('The name of the Virtual Network.')
param vNetName string

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2022-09-01' existing = { 
  name: vNetName
}

resource subNet 'Microsoft.Network/virtualNetworks/subnets@2022-07-01' = {
  name: subNetName
  parent: virtualNetwork
  properties: {
    addressPrefix: '${addressPrefix}/${addressSuffix}'
    delegations: delegations
    serviceEndpoints: serviceEndpoints
  }
}

output cidr string = subNet.properties.addressPrefix
output name string = subNet.name
output id string = subNet.id
