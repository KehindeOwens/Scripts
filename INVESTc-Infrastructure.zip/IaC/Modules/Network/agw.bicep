targetScope = 'resourceGroup'

@description('Backend address pool of the application gateway resource. Defaults to empty array.')
param backendAddressPools array = []

@description('Backend http settings of the application gateway resource. Defaults to empty array.')
param backendHttpSettingsCollection array = []

@description('The cert alias of the ssl certificate to associate to the application gateway. This will not be the full name of the actual certificate.(ex - investc-dsr-ui)')
param certificateName string

@description('Web application firewall mode. Defaults to Detection')
@allowed([
  'Detection'
  'Prevention'
])
param fireWallMode string = 'Detection'

@description('Probes of the application gateway resource. Defaults to empty array.')
param healthProbes array = []

@description('Http Listeners of the application gateway resource. Defaults to empty array.')
param httplistener array = []

@description('Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in KeyVault. Format is https://vaultname.vault.azure.net/secrets/certificatename.')
param keyVaultCertificateId string

@description('The name of the Application Gateway.')
param name string

@description('Application Gateway SKU tier. Defaults to WAF_v2.')
@allowed([
  'Standard'
  'Standard_v2'
  'WAF'
  'WAF_v2'
])
param skuTier string = 'WAF_v2'

@description('Application Gateway SKU type. Defaults to WAF_v2.')
@allowed([
  'Standard_Large'
  'Standard_Medium'
  'Standard_Small'
  'Standard_v2'
  'WAF_Large'
  'WAF_Medium'
  'WAF_v2'
])
param skuType string = 'WAF_v2'

@description('Resource location')
param region string = resourceGroup().location

@description('Request routing rules of the application gateway resource. Defaults to empty array.')
param requestRoutingRules array = []

@description('The name of the Public IP')
param pubIpName string

@description('The name of the user assigned identity of the application gateway')
param umiName string

@description('URL path map of the application gateway resource. Defaults to empty array.')
param urlPathMaps array = []

@description('The name of the Virtual Network.')
param vNetName string

resource umi 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = { 
  name: umiName
}

resource pubIp 'Microsoft.Network/publicIPAddresses@2022-07-01' existing = { 
  name: pubIpName
}

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2022-09-01' existing = { 
  name: vNetName
}

resource applicationGateway 'Microsoft.Network/applicationGateways@2023-04-01' = {
  name: name
  location: region
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${umi.id}': {}
    }
  }
  properties: {
    sku: {
      name: skuType
      tier: skuTier
      capacity: 2
    }
    gatewayIPConfigurations: [
      {
        name: 'agw-ip-cfg'
        properties: {
          subnet: {
            id: '${virtualNetwork.id}/subnets/agw'
          }
        }
      }
    ]
    sslCertificates: [
      {
        name: certificateName
        properties: {
          keyVaultSecretId: keyVaultCertificateId
        }
      }
    ]
    trustedRootCertificates: []
    trustedClientCertificates: []
    sslProfiles: []
    frontendIPConfigurations: [
      {
        name: 'agw-pip'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          publicIPAddress: {
            id: pubIp.id
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'agw-feport'
        properties: {
          port: 443
        }
      }
    ]
    backendAddressPools: backendAddressPools
    loadDistributionPolicies: []
    backendHttpSettingsCollection: backendHttpSettingsCollection 
    listeners: []
    httpListeners: httplistener
    urlPathMaps: urlPathMaps 
    requestRoutingRules: requestRoutingRules
    routingRules: []
    probes: healthProbes
    rewriteRuleSets: []
    redirectConfigurations: []
    privateLinkConfigurations: []
    sslPolicy: {
      disabledSslProtocols: []
    }
    webApplicationFirewallConfiguration: {
      enabled: true
      firewallMode: fireWallMode
      ruleSetType: 'OWASP'
      ruleSetVersion: '3.0'
      disabledRuleGroups: []
      requestBodyCheck: true
      maxRequestBodySizeInKb: 128
      fileUploadLimitInMb: 100
    }
    enableHttp2: false
    customErrorConfigurations: []
  }
}

output name string = applicationGateway.name
output id string = applicationGateway.id
