targetScope = 'resourceGroup'

@description('The canonical name for this CNAME record.')
param canonicalName string

@description('The name of the DNS Zone to Retrieve in order to create the sub cname records.')
param dnsZoneName string

@description('The Name of the CNAME record. This will also be used as the context of the CNAME record as well.')
param recordName string

resource dnsZone 'Microsoft.Network/privateDnsZones@2018-09-01' existing = {
  name: dnsZoneName
}

resource cnameRecord 'Microsoft.Network/privateDnsZones/CNAME@2018-09-01' = {
  parent: dnsZone
  name: recordName
  properties: {
    ttl: 300
    cnameRecord: {
      cname: canonicalName
    }
  }
}

output name string = cnameRecord.name
output id string = cnameRecord.id
