targetScope = 'resourceGroup'

@description('The name of the DNS Zone to Retrieve in order to create the sub cname records.')
param dnsZoneName string

@description('The name of the virtual network link resource.')
param name string

@description('The name of the virtual network to link the private dns zone to.')
param vNetId string

resource dnsZone 'Microsoft.Network/privateDnsZones@2018-09-01' existing = {
  name: dnsZoneName
}

resource privateDnsZones_vnetlink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2018-09-01' = {
  parent: dnsZone
  name: name
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {
      id: vNetId
    }
  }
}

output name string = privateDnsZones_vnetlink.name
output id string = privateDnsZones_vnetlink.id
