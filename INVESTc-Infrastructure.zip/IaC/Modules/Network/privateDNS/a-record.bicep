targetScope = 'resourceGroup'

@description('The IPv4 address of this A record.')
param ipv4Address string

@description('The name of the DNS Zone to Retrieve in order to create the sub cname records.')
param dnsZoneName string

@description('The Name of the A record. This will also be used as the context of the A record as well.')
param recordName string

resource dnsZone 'Microsoft.Network/privateDnsZones@2018-09-01' existing = {
  name: dnsZoneName
}

resource aRecord 'Microsoft.Network/privateDnsZones/A@2018-09-01' = {
  parent: dnsZone
  name: recordName
  properties: {
    ttl: 300
    aRecords: [
      {
        ipv4Address: ipv4Address
      }
    ]
  }
}

output name string = aRecord.name
output id string = aRecord.id
