@description('The IPv4 address of this A record.')
param ipv4Address string

@description('The name of the private DNS Zone.')
param name string

resource privateDnsZone 'Microsoft.Network/privateDnsZones@2018-09-01' = {
  name: name
  location: 'global'
  properties: {
  }
}

resource privateDnsZone_SOA 'Microsoft.Network/privateDnsZones/SOA@2018-09-01' = {
  parent: privateDnsZone
  name: '@'
  properties: {
    ttl: 3600
    soaRecord: {
      email: 'azuredns-hostmaster.microsoft.com'
      expireTime: 2419200
      host: 'azureprivatedns.net'
      minimumTtl: 300
      refreshTime: 3600
      retryTime: 300
      serialNumber: 1
    }
  }
}

resource privateDnsZone_wildCard 'Microsoft.Network/privateDnsZones/A@2018-09-01' = {
  parent: privateDnsZone
  name: '*'
  properties: {
    ttl: 300
    aRecords: [
      {
        ipv4Address: ipv4Address
      }
    ]
  }
}

resource privateDnsZone_wildCard_scm 'Microsoft.Network/privateDnsZones/A@2018-09-01' = {
  parent: privateDnsZone
  name: '*.scm'
  properties: {
    ttl: 300
    aRecords: [
      {
        ipv4Address: ipv4Address
      }
    ]
  }
}

resource privateDnsZone_wildCard_asperand 'Microsoft.Network/privateDnsZones/A@2018-09-01' = {
  parent: privateDnsZone
  name: '@'
  properties: {
    ttl: 300
    aRecords: [
      {
        ipv4Address: ipv4Address
      }
    ]
  }
}


output name string = privateDnsZone.name
output id string = privateDnsZone.id
