targetScope = 'resourceGroup'

@description('The name of the Bastion host')
param bastionHostName string

@description('The name of the Pubic IP')
param pubIpName string

@description('Resource location')
param region string = resourceGroup().location

@allowed([
  'Standard'
  'Basic'
])
@description('The sku of this Bastion Host. Default value is Basic')
param sku string = 'Standard'

@allowed([
  'Static'
  'Dynamic'
])
@description('Private IP allocation method. Default value is Dynamic')
param ipAllocation string = 'Dynamic'

@description('The scale units for the Bastion Host resource. Default value is 2')
param scaleUnits int = 2

@description('The name of the virtual network')
param vNetName string

resource pubIp 'Microsoft.Network/publicIPAddresses@2022-07-01' existing = { 
  name: pubIpName
}

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2022-09-01' existing = {
  name: vNetName 
}

resource bastionHost 'Microsoft.Network/bastionHosts@2022-11-01' = {
  name: bastionHostName
  location: region
  sku: {
    name: sku
  }
  properties: {
    disableCopyPaste: false
    enableFileCopy: true
    enableIpConnect: true
    enableKerberos: true
    enableShareableLink: true
    scaleUnits: scaleUnits
    ipConfigurations: [
      {
        name: 'configuration'
        properties: {
          privateIPAllocationMethod: ipAllocation
          publicIPAddress: {
            id: pubIp.id
          }
          subnet: {
            id: '${virtualNetwork.id}/subnets/AzureBastionSubnet'
          }
        }
      }
    ]
  }
}

output name string = bastionHost.name
output id string = bastionHost.id
