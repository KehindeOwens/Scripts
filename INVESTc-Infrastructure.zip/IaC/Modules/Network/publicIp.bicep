targetScope = 'resourceGroup'

@description('The public IP address version. Defaults to IPv4')
@allowed([
  'IPv4'
  'IPv6'
])
param addressVersion string = 'IPv4'

@description('The public IP address allocation method. Defaults to Static')
@allowed([
  'Dynamic'
  'Static'
])
param allocationMethod string = 'Static'

@description('The idle timeout of the public IP address. Defaults to 4')
param idleTimeout int = 4

@description('The name of the Pubic IP')
param name string

@description('Resource location')
param region string = resourceGroup().location

@description('Tier of a public IP address SKU. Defaults to Regional')
param skuTier string = 'Regional'

@description('The public IP address SKU. Defaults to Standard.')
@allowed([
  'Basic'
  'Standard'
])
param skuType string = 'Standard'

@description('A list of availability zones denoting the IP allocated for the resource needs to come from. Defaults to empty array.')
param zones string[] = []

resource publicIP 'Microsoft.Network/publicIPAddresses@2022-11-01' = {
  name: name
  location: region
  sku: {
    name: skuType
    tier: skuTier
  }
  properties: {
    publicIPAddressVersion: addressVersion
    publicIPAllocationMethod: allocationMethod
    idleTimeoutInMinutes: idleTimeout
    ipTags: []
  }
  zones: zones
}

output name string = publicIP.name
output id string = publicIP.id
