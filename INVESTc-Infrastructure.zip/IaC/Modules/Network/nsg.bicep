targetScope = 'resourceGroup'

@description('Connection flushing, defaults to false as its not supported in all regions.')
param flushConnection bool = false

@description('The name of the Network Security Group.')
param name string

@description('Rules to be added to the NSG. Defaults to empty array.')
param securityRules array = []

@description('Resource location')
param region string = resourceGroup().location

resource networkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2022-11-01' = {
  name: name
  location: region
  properties: {
    flushConnection: flushConnection
    securityRules: securityRules
  }
}

output name string = networkSecurityGroup.name
output id string = networkSecurityGroup.id
