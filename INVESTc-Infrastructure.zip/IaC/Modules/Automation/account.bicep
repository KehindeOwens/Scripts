targetScope = 'resourceGroup'

@description('The name of the automation account.')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@allowed([
  'Basic'
  'Free'
])
@description('The sky type of the automation account. Defaults to basic.')
param skuType string = 'Basic'

resource automationAccount 'Microsoft.Automation/automationAccounts@2022-08-08' = {
  name: name
  location: region
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    sku: {
      name: skuType
    }
    encryption: {
      keySource: 'Microsoft.Automation'
      identity: {}
    }
  }
}


