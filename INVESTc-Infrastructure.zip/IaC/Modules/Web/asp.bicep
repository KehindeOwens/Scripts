targetScope = 'resourceGroup'

@description('The name of the app service environment to deploy the app service plan in.')
param aseName string

@description('The name of the app service plan.')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('The operating system type that the asp runs on. Defaults value is app(which is windows).')
@allowed([
  'app'
  'linux'
])
param OS string = 'app'

@description('Current number of instances assigned to the asp. Defaults to 1.')
param skuCapacity int = 1

@description('The sku family of the asp. Defaults to I1v2.')
param skuFamily string = 'I2v2'

@description('The sku name of the asp. Defaults to I1v2.')
param skuName string = 'I2v2'

@description('The sku tier of the asp. Defaults to Isolatedv2')
param skuTier string = 'IsolatedV2'

@description('The sku size of the asp. Defaults to I1v2.')
param skuSize string = 'I2v2'

@description('Whether or not this App Service plan is zone-redundant. Defaults to false.')
param zoneRedundant bool = false

resource ase 'Microsoft.Web/hostingEnvironments@2022-09-01' existing = {
  name: aseName
}

resource asp 'Microsoft.Web/serverfarms@2022-09-01' = {
  name: name
  location: region
  sku: {
    name: skuName
    tier: skuTier
    size: skuSize
    family: skuFamily
    capacity: skuCapacity
  }
  kind: OS
  properties: {
    hostingEnvironmentProfile: {
      id: ase.id
    }
    perSiteScaling: false
    elasticScaleEnabled: false
    maximumElasticWorkerCount: 0
    isSpot: false
    reserved: false
    isXenon: false
    hyperV: false
    targetWorkerCount: 0
    targetWorkerSizeId: 0
    zoneRedundant: zoneRedundant
  }
}

output name string = asp.name
output id string = asp.id
