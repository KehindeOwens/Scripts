targetScope = 'resourceGroup'

@description('The default custom domain suffix to use for all sites deployed on the ASE.')
param dnsSuffix string

@description('The name of the key vault in order to pull the SSL certificate for the ASE.')
param keyVaultName string

@description('The user-assigned identity to use for resolving the key vault certificate reference. If not specified, the system-assigned ASE identity will be used if available.')
param keyVaultReferenceIdentity string

@description('The name of the app service environment.')
param name string

@description('The name of the subnet associated to the ASE.')
param subnetName string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@description('The name of the virtual network to associate the ilbase subnet to the ASE.')
param vNetName string

@description('The Resource Group that the Virtual Network Resides in.')
param vNetRG string

@description('Upgrade preference. Defaults to None.')
@allowed([
  'Early'
  'Late'
  'Manual'
  'None'
])
param upgradePreference string = 'None'

@description('Resource Id of the Apps Managed Identity.')
param umiAppId string

@description('Whether or not this App Service Environment is zone-redundant. Defaults to false.')
param zoneRedundant bool = false

resource virtualNetwork 'Microsoft.Network/virtualNetworks@2021-08-01' existing = {
  scope: resourceGroup(vNetRG)
  name: vNetName
}

resource keyVault 'Microsoft.KeyVault/vaults@2023-02-01' existing = {
  scope: resourceGroup(vNetRG)
  name: keyVaultName
}

resource ase 'Microsoft.Web/hostingEnvironments@2022-09-01' = {
  name: name
  location: region
  kind: 'ASEV3'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${umiAppId}': {}
    }
  }
  properties: {
    virtualNetwork: {
      id: '${virtualNetwork.id}/subnets/${subnetName}'
    }
    customDnsSuffixConfiguration: {
        certificateUrl: 'https://${keyVault.name}.vault.azure.net/secrets/ase-cert'
        dnsSuffix: dnsSuffix
        keyVaultReferenceIdentity: keyVaultReferenceIdentity
    } 
    internalLoadBalancingMode: 'Web, Publishing'
    multiSize: 'Standard_D2d_v4'
    ipsslAddressCount: 0
    frontEndScaleFactor: 15
    upgradePreference: upgradePreference
    zoneRedundant: zoneRedundant
    dedicatedHostCount: 0
  }
}

output name string = ase.name
output id string = ase.id
output internalInboundIpAddress string = ase.properties.networkingConfiguration.internalInboundIpAddresses[0]
output suffix string = ase.properties.dnsSuffix

