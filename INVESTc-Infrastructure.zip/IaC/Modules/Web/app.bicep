targetScope = 'resourceGroup'

@description('if Always On is enabled; otherwise. Default value it true.')
param alwaysOn bool = true

@description('The name of the app service environment to deploy the function app in.')
param aseName string

@description('The name of the app service plan to deploy the function app in.')
param aspName string

@description('If the app is enabled; otherwise,Setting this value to false disables the app (takes the app offline). Default value it true.')
param appEnabled bool = true

param appInsightsId string
@secure()

param appInsightsInstrumentationKey string
@secure()

param appInsightsConnectionString string

@description('The name of the Function App Resource.')
param appName string

@description('What type of app is being deployed. app is short for web app.')
@allowed([
  'app'
  'functionapp'
])
param appType string

@description('App Settings for the Web App or Function App') 
param appSettings array = []

@description('This composes with ClientCertEnabled setting. ClientCertEnabled: false means ClientCert is ignored. ClientCertEnabled: true and ClientCertMode: Required means ClientCert is required. ClientCertEnabled: true and ClientCertMode: Optional means ClientCert is optional or accepted. Defaults to Required.')
@allowed([
  'Optional'
  'OptionalInteractiveUser'
  'Required'
])
param clientCertMode string = 'Required'

@description('Gets or sets the list of origins that should be allowed to make cross-origin calls (for example: http://example.com:12345). Use * to allow all. Defaults to empty array.') 
param cors array = []

@description('The Suffix of the DNS Name for the Function App. Ex. "state.local" or "state.stg".')
param dnsSuffix string

@description('Http20Enabled: configures a web site to allow clients to connect over http2.0. Default value it false.')
param http20Enabled bool = false

@description('HttpsOnly: configures a web site to accept only https requests. Issues redirect for http requests. Defaults to false.')
param httpsOnly bool = false

@description('The Azure Region to Deploy the Resource to.')
param region string = resourceGroup().location

@description('Site redundancy mode. Defaults to None.')
@allowed([
  'ActiveActive'
  'Failover'
  'GeoRedundant'
  'Manual'
  'None'
])
param redundancyMode string = 'None'

@description('Checks if Customer provided storage account is required. Default value it false.')
param storageAccountRequired bool = false

@description('To stop SCM (KUDU) site when the app is stopped; otherwise, stay on. Default value it false.')
param scmSiteAlsoStopped bool = false

@description('Resource Id of the Apps Managed Identity.')
param umiAppId string

param tags object = {}

resource ase 'Microsoft.Web/hostingEnvironments@2022-09-01' existing = {
  name: aseName
}

resource asp 'Microsoft.Web/serverfarms@2022-09-01' existing = {
  name: aspName
}

var tagsWithHiddenLinks = union({
  'hidden-link: /app-insights-resource-id': appInsightsId
  'hidden-link: /app-insights-instrumentation-key': appInsightsInstrumentationKey
  'hidden-link: /app-insights-conn-string': appInsightsConnectionString
}, tags)

resource app 'Microsoft.Web/sites@2022-03-01' = {
  name: appName
  location: region
  tags: tagsWithHiddenLinks
  kind: appType
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${umiAppId}': {}
    }
  }
  properties: {
    enabled: appEnabled
    hostNameSslStates: [
      {
        name: '${appName}.scm.${dnsSuffix}'
        sslState: 'Disabled'
        hostType: 'Repository'
      }
      {
        name: '${appName}.${dnsSuffix}'
        sslState: 'Disabled'
        hostType: 'Standard'
      }
    ]
    serverFarmId: asp.id
    reserved: false
    isXenon: false
    hyperV: false
    vnetRouteAllEnabled: false
    vnetImagePullEnabled: false
    vnetContentShareEnabled: true
    siteConfig: {  
      numberOfWorkers: 1
      acrUseManagedIdentityCreds: false
      alwaysOn: alwaysOn
      http20Enabled: http20Enabled
      functionAppScaleLimit: 0
      minimumElasticInstanceCount: 0
      appSettings: appSettings
    }
    scmSiteAlsoStopped: scmSiteAlsoStopped
    hostingEnvironmentProfile: {
      id: ase.id
    }
    clientAffinityEnabled: true
    clientCertEnabled: false
    clientCertMode: clientCertMode
    hostNamesDisabled: false
    containerSize: 1536
    dailyMemoryTimeQuota: 0
    httpsOnly: httpsOnly
    redundancyMode: redundancyMode
    storageAccountRequired: storageAccountRequired
    keyVaultReferenceIdentity: umiAppId
  }
}

resource app_ftp 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2022-03-01' = {
  parent: app
  name: 'ftp'
  properties: {
    allow: true
  }
}

resource app_scm 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2022-03-01' = {
  parent: app
  name: 'scm'
  properties: {
    allow: true
  }
}

resource app_web 'Microsoft.Web/sites/config@2022-03-01' = {
  parent: app
  name: 'web'
  properties: {
    numberOfWorkers: 1
    defaultDocuments: [
      'Default.htm'
      'Default.html'
      'Default.asp'
      'index.htm'
      'index.html'
      'iisstart.htm'
      'default.aspx'
      'index.php'
      'hostingstart.html'
    ]
    netFrameworkVersion: 'v4.0'
    phpVersion: '5.6'
    requestTracingEnabled: false
    remoteDebuggingEnabled: false
    remoteDebuggingVersion: 'VS2019'
    httpLoggingEnabled: false
    acrUseManagedIdentityCreds: false
    logsDirectorySizeLimit: 35
    detailedErrorLoggingEnabled: false
    publishingUsername: '$${appName}'
    scmType: 'VSTSRM'
    use32BitWorkerProcess: true
    webSocketsEnabled: true
    alwaysOn: alwaysOn
    managedPipelineMode: 'Integrated'
    virtualApplications: [
      {
        virtualPath: '/'
        physicalPath: 'site\\wwwroot'
        preloadEnabled: false
      }
    ]
    loadBalancing: 'LeastRequests'
    experiments: {
      rampUpRules: []
    }
    autoHealEnabled: false
    vnetRouteAllEnabled: false
    vnetPrivatePortsCount: 0
    cors: {
      allowedOrigins: cors
      supportCredentials: false
    }
    localMySqlEnabled: false
    ipSecurityRestrictions: [
      {
        ipAddress: 'Any'
        action: 'Allow'
        priority: 2147483647
        name: 'Allow all'
        description: 'Allow all access'
      }
    ]
    scmIpSecurityRestrictions: [
      {
        ipAddress: 'Any'
        action: 'Allow'
        priority: 2147483647
        name: 'Allow all'
        description: 'Allow all access'
      }
    ]
    scmIpSecurityRestrictionsUseMain: false
    http20Enabled: false
    minTlsVersion: '1.2'
    scmMinTlsVersion: '1.0'
    ftpsState: 'AllAllowed'
    preWarmedInstanceCount: 0
    functionAppScaleLimit: 0
    functionsRuntimeScaleMonitoringEnabled: false
    minimumElasticInstanceCount: 0
    azureStorageAccounts: {}
  }
}

resource app_binding 'Microsoft.Web/sites/hostNameBindings@2022-03-01' = {
  parent: app
  name: '${appName}.${dnsSuffix}'
  properties: {
    siteName: appName
    hostNameType: 'Verified'
  }
}

output name string = app.name
output id string = app.id
output fqdn string = app.properties.defaultHostName

