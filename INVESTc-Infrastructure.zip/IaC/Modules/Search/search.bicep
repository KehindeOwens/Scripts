targetScope = 'resourceGroup'

@description('The SKU of the Search Service, which determines price tier and capacity limits. This property is required when creating a new Search Service. Defaults to standard.')
@allowed([
  'default'
  'highDensity'
])
param hostingMode string = 'default'

@description('The name of the cognitive search resource')
param name string 

@description('Resource location')
param region string = resourceGroup().location

@description('This value can be set to enabled to avoid breaking changes on existing customer resources and templates. If set to disabled, traffic over public interface is not allowed, and private endpoint connections would be the exclusive access method.')
@allowed([
  'disabled'
  'enabled'
])
param publicNetworkAccess string = 'enabled'

@description('The SKU of the Search Service, which determines price tier and capacity limits. This property is required when creating a new Search Service. Defaults to standard.')
@allowed([
  'basic'
  'free'
  'standard'
  'standard2'
  'standard3'
  'storage_optimized_l1'
  'storage_optimized_l2'
])
param sku string = 'standard'

resource cognitiveSearch 'Microsoft.Search/searchServices@2022-09-01' = {
  name: name
  location: region
  sku: {
    name: sku
  }
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    replicaCount: 1
    partitionCount: 1
    hostingMode: hostingMode
    publicNetworkAccess: publicNetworkAccess
    networkRuleSet: {
      ipRules: []
    }
    disableLocalAuth: false
    authOptions: {
      apiKeyOnly: {}
    }
  }
}

output name string = cognitiveSearch.name
output id string = cognitiveSearch.id
