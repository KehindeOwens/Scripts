targetScope = 'resourceGroup'

@description('The name of the recovery services vault.')
param name string

@description('The Region that the Resource will be deployed into.')
param region string = resourceGroup().location

@allowed([
  'RS0'
  'Standard'
])
@description('Name of SKU is RS0 (Recovery Services 0th version) and the tier is standard tier. They do not have affect on backend storage redundancy or any other vault settings. To manage storage redundancy, use the backupstorageconfig. Defaults to RS0.')
param skuName string = 'RS0'

@allowed([
  'Basic'
  'Standard'
])
@description('The sku tier. Defaults to Standard.')
param skuTier string = 'Standard'

@allowed([
  'Disabled'
  'Enabled'
])
@description('property to enable or disable resource provider inbound network traffic from public clients. Defaults to Enabled.')
param publicNetworkAccess string = 'Enabled'

resource recoveryVault 'Microsoft.RecoveryServices/vaults@2024-04-01' = {
  name: name
  location: region
  sku: {
    name: skuName
    tier: skuTier
  }
  properties: {
    moveDetails: {}
    publicNetworkAccess: publicNetworkAccess
    redundancySettings: {}
    restoreSettings: {}
    securitySettings: {}
    upgradeDetails: {}
  }
}
